# Data Model - Katsu Zushi Business Management

All data is stored as JSON files in `C:/Users/user/.workbuddy-ai/skills/business-solution/data/`.

---

## 1. config.json

```json
{
  "business_name": "Katsu Zushi",
  "business_type": "F&B",
  "currency": "RM",
  "costing_method": "weighted_average",
  "timezone": "Asia/Kuala_Lumpur",
  "expense_categories": [
    "Rent",
    "Staff Salaries",
    "Utilities",
    "Packaging",
    "Delivery and Platform Commissions",
    "Marketing",
    "Equipment and Maintenance",
    "Cleaning Supplies",
    "Transportation",
    "Other Operating Expenses"
  ],
  "initialized": true,
  "init_date": "2025-01-01T00:00:00"
}
```

---

## 2. ingredients.json

```json
{
  "ingredients": [
    {
      "id": "ing_001",
      "name": "Panko Breadcrumbs",
      "alternative_names": ["Japanese Breadcrumbs", "Panko"],
      "standard_unit": "g",
      "pack_size_qty": 1,
      "pack_size_unit": "1000",
      "pack_size_measure": "g",
      "current_stock_qty": 5,
      "current_stock_amount": 5000,
      "current_stock_display": "5 Qty + 0 g",
      "pending_stock_qty": 0,
      "pending_stock_amount": 0,
      "weighted_avg_cost_per_unit": 0.012,
      "last_purchase_price": 12.00,
      "last_purchase_supplier": "Supplier A",
      "last_updated": "2025-01-01T00:00:00",
      "created": "2025-01-01T00:00:00"
    }
  ]
}
```

Key fields:
- `standard_unit`: The base measurement unit (g, ml, piece, etc.)
- `pack_size_qty`: Number of units in one pack (e.g., 1 pack)
- `pack_size_unit`: The quantity value per pack (e.g., 1000)
- `pack_size_measure`: The measurement per pack (e.g., g)
- `current_stock_qty`: Number of full packs remaining
- `current_stock_amount`: Total amount in standard unit (e.g., 5000 g)
- `weighted_avg_cost_per_unit`: Weighted average cost per standard unit

---

## 3. recipes.json

```json
{
  "recipes": [
    {
      "id": "rec_001",
      "menu_item": "Chicken Katsu Don",
      "ingredients": [
        {
          "name": "Chicken Breast",
          "quantity": 120,
          "unit": "g"
        },
        {
          "name": "Panko Breadcrumbs",
          "quantity": 50,
          "unit": "g"
        },
        {
          "name": "Egg",
          "quantity": 1,
          "unit": "piece"
        }
      ],
      "serving_size": "1 bowl",
      "selling_price": 15.90,
      "recipe_version": "1.0",
      "last_updated": "2025-01-01",
      "created": "2025-01-01T00:00:00"
    }
  ]
}
```

---

## 4. inventory.json

```json
{
  "inventory": [
    {
      "ingredient_id": "ing_001",
      "ingredient_name": "Panko Breadcrumbs",
      "previous_stock_qty": 2,
      "previous_stock_amount": 2000,
      "stock_added_qty": 3,
      "stock_added_amount": 3000,
      "stock_used_qty": 0,
      "stock_used_amount": 0,
      "current_stock_qty": 5,
      "current_stock_amount": 5000,
      "current_stock_display": "5 Qty + 0 g",
      "status": "OK",
      "last_updated": "2025-01-01T00:00:00"
    }
  ]
}
```

---

## 5. batches.json

```json
{
  "batches": [
    {
      "id": "bat_001",
      "ingredient_id": "ing_001",
      "ingredient_name": "Panko Breadcrumbs",
      "supplier": "Supplier A",
      "po_reference": "PO-2025-001",
      "purchase_date": "2025-01-01",
      "receipt_date": "2025-01-01",
      "registration_date": "2025-01-01T00:00:00",
      "quantity_received_qty": 3,
      "quantity_received_amount": 3000,
      "pack_size": "1000 g per pack",
      "unit": "g",
      "actual_expiry_date": null,
      "estimated_expiry_date": "2025-07-01",
      "shelf_life_days": 180,
      "storage_conditions": "Room Temperature",
      "remaining_qty": 3,
      "remaining_amount": 3000,
      "expiry_status": "OK",
      "expiry_type": "estimated",
      "active": true,
      "created": "2025-01-01T00:00:00"
    }
  ]
}
```

Key fields:
- `actual_expiry_date`: From product/PO documentation (null if unknown)
- `estimated_expiry_date`: Calculated from shelf-life reference
- `expiry_type`: "confirmed" if actual date, "estimated" if calculated
- `active`: false when batch is fully consumed or removed

---

## 6. suppliers.json

```json
{
  "suppliers": [
    {
      "id": "sup_001",
      "name": "Supplier A",
      "contact": null,
      "address": null,
      "phone": null,
      "created": "2025-01-01T00:00:00"
    }
  ],
  "price_records": [
    {
      "id": "pr_001",
      "ingredient_name": "Panko Breadcrumbs",
      "supplier": "Supplier A",
      "purchase_date": "2025-01-01",
      "po_reference": "PO-2025-001",
      "purchase_qty": 3,
      "purchase_unit": "pack",
      "pack_size": "1000 g per pack",
      "price_per_pack": 12.00,
      "total_purchase_cost": 36.00,
      "comparable_unit_price": 0.012,
      "comparable_unit": "g",
      "discounts": 0,
      "delivery_charges": 0,
      "effective_price_per_pack": 12.00,
      "effective_unit_price": 0.012,
      "price_type": "listed",
      "created": "2025-01-01T00:00:00"
    }
  ]
}
```

---

## 7. sales.json

```json
{
  "sales": [
    {
      "id": "sale_001",
      "sales_date": "2025-01-02",
      "menu_item": "Chicken Katsu Don",
      "quantity_sold": 20,
      "selling_price": 15.90,
      "gross_sales": 318.00,
      "discounts": 0,
      "refunds": 0,
      "cancelled_orders": 0,
      "net_sales_revenue": 318.00,
      "source_document": "daily_sales_2025-01-02.pdf",
      "processed": true,
      "created": "2025-01-02T00:00:00"
    }
  ]
}
```

---

## 8. transactions.json

```json
{
  "transactions": [
    {
      "id": "txn_001",
      "date": "2025-01-01",
      "ingredient_name": "Panko Breadcrumbs",
      "quantity": 3000,
      "unit": "g",
      "transaction_type": "addition",
      "source_document": "PO-2025-001",
      "reason": "Stock received from PO",
      "batch_id": "bat_001",
      "value": 36.00,
      "created": "2025-01-01T00:00:00"
    },
    {
      "id": "txn_002",
      "date": "2025-01-02",
      "ingredient_name": "Panko Breadcrumbs",
      "quantity": 1000,
      "unit": "g",
      "transaction_type": "deduction",
      "source_document": "daily_sales_2025-01-02.pdf",
      "reason": "Sales deduction - 20x Chicken Katsu Don",
      "batch_id": "bat_001",
      "value": 12.00,
      "allocation_method": "FEFO",
      "allocation_estimated": false,
      "created": "2025-01-02T00:00:00"
    }
  ]
}
```

Transaction types: `addition`, `deduction`, `correction`, `write_off`, `transfer`

---

## 9. expenses.json

```json
{
  "expenses": [
    {
      "id": "exp_001",
      "date": "2025-01-05",
      "category": "Rent",
      "description": "January shop rent",
      "payee": "Building Management",
      "amount": 3000.00,
      "currency": "RM",
      "payment_status": "paid",
      "supporting_document": null,
      "source_file": null,
      "file_hash": null,
      "created": "2025-01-05T00:00:00"
    }
  ]
}
```

---

## 10. expiry_ref.json

```json
{
  "expiry_reference": [
    {
      "id": "exp_ref_001",
      "ingredient_category": "Frozen Meat",
      "ingredient_name": "Chicken Breast",
      "shelf_life_days": 180,
      "storage_conditions": "Frozen (-18C)",
      "shelf_life_source": "Expiry Reference PDF",
      "notes": "Vacuum sealed extends 30 days",
      "created": "2025-01-01T00:00:00"
    }
  ]
}
```

---

## 11. processed_files.json

```json
{
  "processed_files": [
    {
      "file_name": "menu.pdf",
      "file_hash": "a1b2c3d4e5f6...",
      "file_type": "menu",
      "processed_date": "2025-01-01T00:00:00",
      "records_created": 15,
      "status": "success"
    }
  ]
}
```

---

## ID Generation

All IDs are generated as: `<prefix>_<sequential_number>` padded to 3 digits.
- Ingredients: `ing_001`
- Recipes: `rec_001`
- Batches: `bat_001`
- Suppliers: `sup_001`
- Sales: `sale_001`
- Transactions: `txn_001`
- Expenses: `exp_001`
- Price records: `pr_001`
- Expiry refs: `exp_ref_001`
- Processed files: `pf_001`
