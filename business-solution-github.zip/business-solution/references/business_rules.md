# Business Rules - Katsu Zushi Business Management

Complete rules governing all four features. These rules are MANDATORY and must be followed exactly.

---

## 1. Data Integrity Rules

### 1.1 No Fabrication
- NEVER invent recipes, ingredient quantities, supplier prices, sales figures, expiry dates, or expenses
- If data is missing, ASK the user
- If a calculation depends on missing data, explain what is missing

### 1.2 No Silent Corrections
- Never silently change historical records
- Record correction transactions with date, reason, and source
- Retain all original records

### 1.3 No Overwriting
- Never overwrite existing stock balance with new purchase quantity (ADD, don't replace)
- Never overwrite previous supplier prices with new prices (APPEND)
- Never overwrite existing recipes without version tracking

### 1.4 Label Estimates
- Estimated expiry dates must be labeled "Estimated"
- Preliminary profit must be labeled "Preliminary" or "Estimated"
- Never present estimates as confirmed

---

## 2. Unit and Quantity Rules (CRITICAL)

### 2.1 Standard Units
Every ingredient has ONE standard measurement unit (g, ml, piece, etc.).

### 2.2 Pack Size Recording
Each purchase records its actual pack size. Different purchases of the same ingredient may have different pack sizes.

### 2.3 Conversion Rules
| Conversion | Rule |
|---|---|
| kg to g | multiply by 1000 |
| L to ml | multiply by 1000 |
| box/bottle/pack to standard | only when contents are known |
| g to ml | NEVER (different substances have different densities) |
| 1 Qty to 1g | NEVER unless pack size explicitly states |

### 2.4 Leftover Preservation
- Never round up stock quantities
- Never discard leftover grams, ml, or pieces
- Display remaining stock as "N Qty + leftover unit"
- Example: 3,500g with 1,000g packs = "3 Qty + 500 g"

### 2.5 Negative Stock
- If stock would become negative, display shortage warning
- Show the missing quantity
- Do NOT silently set to zero
- Do NOT invent stock to cover the shortage

---

## 3. Inventory Rules

### 3.1 Stock Top-Up (PO Processing)
1. Only add stock when receipt is confirmed OR user explicitly says to treat as received
2. If PO is merely an order (delivery not confirmed), record as pending stock
3. Add to existing balance, do NOT replace
4. Create separate batch per purchase
5. Record purchase price and supplier information
6. Update supplier price comparisons and financial records

### 3.2 Stock Deduction (Sales Processing)
1. Match each menu item with stored recipe
2. Calculate: usage = qty_sold x ingredient_per_serving
3. Use FEFO for batch allocation
4. Exclude cancelled/refunded orders
5. Do NOT deduct twice for the same sale
6. If recipe is missing, ASK - do NOT invent ingredients
7. Check processed_files.json to prevent duplicate processing

### 3.3 Inventory Display
Required columns: Ingredient | Previous Stock | Stock Added | Stock Used | Current Stock | Status

Show stock in both Qty and equivalent measurement amount.

---

## 4. Expiry Rules

### 4.1 Batch Integrity
- Never merge batches with different expiry dates
- Each PO stock receipt = one batch
- When batch reaches zero, mark inactive but retain history

### 4.2 Expiry Date Priority
1. Actual expiry date (product label or PO documentation)
2. Shelf-life from Expiry Reference PDF
3. Reasonable estimate with available info
4. Ask user if insufficient info

### 4.3 Date Rules
- Use actual receipt date as starting point for shelf-life calculations
- PO upload date = registration date, NOT necessarily purchase/receipt/production date
- Never present estimated as confirmed

### 4.4 Storage Conditions
- Do NOT assume same shelf life for refrigerated, frozen, and room-temperature
- If storage conditions unknown, ask or use most conservative estimate and label

### 4.5 Warning Thresholds

| Shelf Life | Warning Period | When to Warn |
|---|---|---|
| > 7 days | 7 days before expiry | Trigger warning |
| <= 7 days | 1 day before expiry | Trigger warning |
| Already expired | Immediate | Prominent expired warning |

- Do NOT show routine warning before threshold (unless immediate food-safety concern)
- For expired: show batch, remaining quantity, mark for review and removal from usable inventory
- Do NOT recommend using expired ingredients

### 4.6 FEFO (First Expired, First Out)
1. Sort active batches by expiry date (earliest first)
2. Skip expired batches (flag for review)
3. Deduct from earliest-expiring eligible batch first
4. If batch exhausted, move to next
5. If sales don't identify batch, allocate by FEFO and record as "estimated allocation"
6. Record expired/spoiled/discarded quantities and costs for financial reporting

### 4.7 Expiry Display
Required columns: Ingredient | Batch | Remaining Stock | Expiry Date | Days Remaining | Status

Label expiry dates as "Confirmed" or "Estimated".

---

## 5. Supplier Comparison Rules

### 5.1 Price Recording
- Extract from every PO: ingredient, supplier, date, PO ref, qty, unit, pack size, price per pack, total cost, discounts, delivery charges
- Maintain ALL historical prices (never overwrite)
- Calculate comparable unit price = price_per_pack / pack_content_in_standard_unit

### 5.2 Fair Comparison
- Compare equivalent products using same standard unit
- Do NOT compare only total PO value or package price
- Compare price per g, kg, ml, L, piece, or suitable unit
- Identify differences in brand, grade, quality, packaging
- Account for discounts and delivery charges when data available
- State whether using listed or effective prices
- If data incomplete, explain limitation
- Do NOT invent missing prices

### 5.3 Lowest-Price Identification
1. Identify lowest comparable unit price supplier
2. Show all recorded supplier offers
3. Calculate highest-lowest difference
4. Estimate savings for specified quantity
5. If only one supplier: label "Only one supplier recorded"
6. Preserve historical prices for trend analysis
7. Do NOT auto-place orders - provide recommendations for user review

### 5.4 Display
Columns: Ingredient | Supplier | Pack Size | Price per Pack | Unit Price | Ranking

---

## 6. Financial Rules

### 6.1 Revenue
- Gross Sales = Total sales before discounts and refunds
- Net Sales Revenue = Gross - Discounts - Refunds
- Do NOT subtract twice if report already provides net sales
- Use actual sales records and prices
- Do NOT assume every menu item has same selling price

### 6.2 Ingredient Costs
- Use actual menu recipes, sales quantities, and recorded costs
- Prefer weighted-average cost unless specified otherwise
- Do NOT treat entire PO value as consumed cost in same period
- Ingredients in usable inventory remain as inventory value, NOT consumed cost
- Do NOT count same ingredient cost in both COGS and operating expenses

### 6.3 COGS
- COGS = Opening Inventory + Purchases + Eligible Costs - Closing Inventory - Write-offs
- Alternatively: recipe-based consumption cost
- Reconcile both methods where possible
- Never double-count ingredient costs

### 6.4 Operating Expenses
- Total Operating Expenses = all recognized expenses NOT in COGS
- Track unpaid invoices separately from paid
- Prevent duplicate expense records
- Support: Rent, Salaries, Utilities, Gas, Packaging, Delivery/Platform, Marketing, Equipment/Maintenance, Cleaning, Transportation, Other
- User can add/edit/remove categories

### 6.5 Profit Labels
- If important expenses missing → "Preliminary Profit"
- If significant adjustments needed → "Estimated Profit"
- Never present operating profit as final net profit when items are missing
- Never present preliminary as verified

### 6.6 Margin
- Net Profit Margin = Net Profit / Net Sales Revenue x 100
- If revenue = 0 → display "N/A" (do NOT divide by zero)
- If selling price = 0 for menu item → margin = "N/A"

### 6.7 Inventory Waste
- Record costs of expired/spoiled/discarded ingredients
- Include in appropriate adjustment/expense category
- Do NOT double-count in COGS

### 6.8 Accounting Principles
- Do NOT treat revenue as profit
- Do NOT treat all purchases as expenses in purchase period
- Distinguish cash flow from accounting profit
- Use consistent accounting basis
- Clearly disclose missing data and assumptions
- Do NOT claim reports are audited or tax-compliant
- Separate factual calculations from AI recommendations

---

## 7. Duplicate Prevention Rules

### 7.1 File Processing
- Check file hash in processed_files.json before processing
- If already processed: skip and inform user
- Do NOT add same PO stock twice
- Do NOT deduct ingredients twice for same sales report
- Do NOT record same expense twice
- Do NOT duplicate supplier price records for same transaction
- Do NOT generate duplicate inventory movements

### 7.2 Correction Handling
- If correction needed: record correction transaction (do NOT silently change history)
- Correction includes: date, reason, original reference, corrected values
- If operation fails: explain which records succeeded and which failed

---

## 8. Display Rules

### 8.1 All Results Inside WorkBuddy
- Display as readable tables, summaries, warnings
- Do NOT open external interface or website
- Do NOT create separate dashboard

### 8.2 Table Formatting
Use Markdown tables with clear headers. Show units in headers or inline.

### 8.3 Missing Data
- Display "Insufficient data" when calculation cannot be completed
- Explain why data is insufficient
- State what information is needed

### 8.4 Status Indicators
| Status | Meaning |
|---|---|
| OK | Stock is healthy, expiry is far |
| Low Stock | Stock below minimum (if set) |
| Shortage | Negative stock, cannot fulfill |
| Warning | Expiry within warning period |
| Expired | Past expiry date |
| Pending | PO not yet confirmed received |

---

## 9. Persistent Storage Rules

### 9.1 Confirmation
- Do NOT claim data saved unless storage operation succeeds
- After save, confirm which records were updated

### 9.2 Atomicity
- If operation fails partway, explain what succeeded and what didn't
- Do NOT leave partial state without explanation

### 9.3 Limitations
- No automatic scheduled tasks (expiry checks run on-demand only)
- No database server (file-based JSON storage)
- Data persists between conversations as long as files exist
- If capability unavailable, explain and implement closest alternative

---

## 10. Testing Checklist

Before declaring skill operational, verify:
- [ ] Ingredient deduction from daily sales
- [ ] Stock top-up from Purchase Orders
- [ ] Unit conversions and leftover quantities
- [ ] Negative stock and shortage warnings
- [ ] Duplicate file and transaction prevention
- [ ] Batch-level expiry tracking
- [ ] 7-day and 1-day expiry warning rules
- [ ] Supplier comparisons using equivalent unit prices
- [ ] Expense recording and duplicate prevention
- [ ] Weekly, monthly, annual, and custom financial calculations
- [ ] Inventory costing and profit without double-counting
- [ ] Persistent storage and data retrieval
