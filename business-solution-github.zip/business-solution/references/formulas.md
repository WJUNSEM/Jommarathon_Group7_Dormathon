# Calculation Formulas - Katsu Zushi Business Management

All formulas used across the four features. Each formula includes the calculation, variables, and a worked example.

---

## FEATURE 1: Inventory Calculations

### 1.1 Ingredient Usage from Sales

```
Ingredient Usage = Quantity Sold x Ingredient Quantity per Serving
```

**Variables:**
- `Quantity Sold`: Number of portions sold (from sales report)
- `Ingredient Quantity per Serving`: Amount required for one portion (from recipe)

**Example:**
- Recipe: Chicken Katsu Don requires 100g Panko Breadcrumbs per serving
- Daily sales: 20 portions
- Usage = 20 x 100g = 2,000g
- Deduct 2,000g from available Panko Breadcrumbs stock

---

### 1.2 Stock Balance After Top-Up

```
New Stock = Existing Stock + Stock Received
```

**Example:**
- Existing Panko Breadcrumbs: 2 Qty (1,000g each) = 2,000g
- New PO: 3 Qty (1,000g each) = 3,000g
- New Stock = 2,000g + 3,000g = 5,000g = 5 Qty

---

### 1.3 Stock Balance After Deduction

```
Remaining Stock = Current Stock - Usage
```

**Display Format:**
```
Remaining = N Qty + leftover_amount unit
```

**Example:**
- Current stock: 5,000g (5 Qty of 1,000g)
- Usage: 1,500g
- Remaining = 5,000 - 1,500 = 3,500g
- Display: "3 Qty + 500 g remaining"
- (3 full packs of 1,000g = 3,000g, plus 500g leftover)

**Critical Rules:**
- Never round up
- Never discard leftover amounts
- If remaining < 0, show shortage warning with missing quantity

---

### 1.4 Unit Conversions

| From | To | Multiplier | Example |
|---|---|---|---|
| kg | g | x 1000 | 2 kg = 2,000 g |
| L | ml | x 1000 | 1.5 L = 1,500 ml |
| box | pieces | depends on contents | 1 box = 12 pieces (if specified) |
| pack | g | pack_size x 1000 | 1 pack of 1000g = 1000g |

**Rules:**
- Never assume g = ml
- Never treat 1 Qty as 1g unless pack size explicitly says so
- Only convert when contents are known

---

### 1.5 Weighted Average Cost

```
WAC = (Previous_Stock_Value + New_Purchase_Value) / (Previous_Stock_Amount + New_Purchase_Amount)
```

**Example:**
- Previous stock: 2,000g at RM0.012/g = RM24.00
- New purchase: 3,000g at RM0.014/g = RM42.00
- WAC = (24.00 + 42.00) / (2,000 + 3,000) = 66.00 / 5,000 = RM0.0132/g

---

## FEATURE 2: Expiry Calculations

### 2.1 Estimated Expiry Date

```
Estimated Expiry Date = Receipt Date + Shelf Life (days)
```

**Priority:**
1. Actual expiry date (from product label or PO)
2. Shelf-life from Expiry Reference PDF
3. Reasonable estimate
4. Ask user

**Example:**
- Receipt date: 1 January 2025
- Shelf life from reference: 180 days (frozen chicken)
- Estimated expiry: 1 January + 180 days = 30 June 2025

---

### 2.2 Days Remaining

```
Days Remaining = Expiry Date - Today's Date
```

**Status mapping:**
- Days Remaining > warning threshold → "OK"
- 0 < Days Remaining <= warning threshold → "Warning"
- Days Remaining <= 0 → "Expired"

---

### 2.3 Warning Date Calculation

```
If shelf_life > 7 days:
    Warning Date = Expiry Date - 7 days
    
If shelf_life <= 7 days:
    Warning Date = Expiry Date - 1 day
```

**Example A (long shelf life):**
- Frozen Chicken Breast, shelf life 180 days
- Expiry date: 30 October
- Warning date: 30 October - 7 = 23 October

**Example B (short shelf life):**
- Fresh fish, shelf life 5 days
- Estimated expiry: 15 October
- Warning date: 15 October - 1 = 14 October

---

### 2.4 FEFO Batch Allocation

```
For each ingredient being deducted:
1. Get all active batches sorted by expiry date (earliest first)
2. Skip batches that are expired (flag for review)
3. Deduct from earliest-expiring eligible batch first
4. If batch is exhausted, move to next batch
5. Record which batch(es) were used and whether allocation is estimated
```

**Example:**
- Need to deduct 1,500g Panko Breadcrumbs
- Batch A: 1,000g, expiry 1 May (earliest)
- Batch B: 2,000g, expiry 1 August
- Deduct 1,000g from Batch A (exhausts it)
- Deduct 500g from Batch B
- Batch A remaining: 0 (mark inactive)
- Batch B remaining: 1,500g

---

## FEATURE 3: Supplier Price Comparison

### 3.1 Comparable Unit Price

```
Comparable Unit Price = Price per Pack / (Pack Content in Standard Unit)
```

**Example:**
- Supplier A: RM12 per pack, 1,000g per pack
  - Unit price = 12 / 1000 = RM0.012/g
- Supplier B: RM7 per pack, 500g per pack
  - Unit price = 7 / 500 = RM0.014/g

---

### 3.2 Effective Price (after discounts and delivery)

```
Effective Price per Pack = Listed Price - Discounts + Delivery Charges
Effective Unit Price = Effective Price per Pack / Pack Content
```

---

### 3.3 Price Difference

```
Price Difference = Highest Unit Price - Lowest Unit Price
```

---

### 3.4 Potential Savings

```
Savings = (Highest Unit Price - Lowest Unit Price) x Purchase Quantity
```

**Example:**
- Panko: Supplier A RM0.012/g, Supplier B RM0.014/g
- Purchase: 10,000g (10kg)
- Savings = (0.014 - 0.012) x 10,000 = RM20.00

---

## FEATURE 4: Financial Calculations

### 4.1 Gross Sales

```
Gross Sales = Sum(Quantity Sold x Selling Price) for all items
```

---

### 4.2 Net Sales Revenue

```
Net Sales Revenue = Gross Sales - Discounts - Refunds
```

**Rule:** If sales report already provides net sales, use that. Do not subtract twice.

---

### 4.3 Cost of Goods Sold (COGS) - Inventory Method

```
COGS = Opening Inventory Value + Inventory Purchases + Eligible Inventory Costs 
       - Closing Inventory Value - Inventory Write-Offs
```

### 4.3b COGS - Recipe-Based Method

```
COGS = Sum(Ingredient Qty Consumed x Cost per Standard Unit) for all ingredients used
```

**Reconciliation:**
```
Difference = COGS (Inventory Method) - COGS (Recipe Method)
```
Investigate significant differences. Use recipe-based as primary when inventory valuation is incomplete.

---

### 4.4 Gross Profit

```
Gross Profit = Net Sales Revenue - COGS
```

---

### 4.5 Total Operating Expenses

```
Total Operating Expenses = Sum of all recognized operating expenses 
                          (excluding costs already in COGS)
```

---

### 4.6 Operating Profit

```
Operating Profit = Gross Profit - Total Operating Expenses
```

---

### 4.7 Net Profit

```
Net Profit = Total Recognized Income - Total Recognized Expenses
```

Where:
- Total Recognized Income = Net Sales Revenue + Other Income
- Total Recognized Expenses = COGS + Total Operating Expenses + Other Expenses

**If items are missing:** Label as "Preliminary Profit" or "Estimated Profit"

---

### 4.8 Net Profit Margin

```
Net Profit Margin (%) = (Net Profit / Net Sales Revenue) x 100
```

**If Net Sales Revenue = 0:** Display "N/A" (do NOT divide by zero)

---

### 4.9 Expense Category Percentage

```
Category Percentage = (Category Total / Total Operating Expenses) x 100
```

---

### 4.10 Menu Item Profitability

```
Estimated Ingredient Cost per Serving = Sum(ingredient_qty_per_serving x cost_per_standard_unit)

Estimated Gross Profit per Serving = Selling Price - Estimated Ingredient Cost per Serving

Estimated Gross Margin (%) = (Estimated Gross Profit per Serving / Selling Price) x 100
```

**If Selling Price = 0:** Display "N/A" for margin

**Example:**
- Chicken Katsu Don selling price: RM15.90
- Ingredients: 120g chicken (RM0.03/g) + 50g panko (RM0.012/g) + 1 egg (RM0.50)
- Cost = (120 x 0.03) + (50 x 0.012) + (1 x 0.50) = 3.60 + 0.60 + 0.50 = RM4.70
- Gross Profit = 15.90 - 4.70 = RM11.20
- Margin = (11.20 / 15.90) x 100 = 70.44%

**Label:** "Estimated" - not net profit after all business expenses

---

### 4.11 Inventory Waste Cost

```
Waste Cost = Sum(expired/spoiled/discarded quantity x cost per standard unit) 
            for all written-off batches
```

Include in financial adjustments. Do not double-count in COGS.

---

### 4.12 Period Comparison

```
Change (Amount) = Current Period Value - Previous Period Value
Change (%) = (Change / Previous Period Value) x 100
```

If previous period value is 0, display "N/A" for percentage.

---

## Summary Table

| Formula | Expression |
|---|---|
| Ingredient Usage | qty_sold x ingredient_per_serving |
| Stock After Top-Up | existing + received |
| Stock After Deduction | current - usage |
| Weighted Avg Cost | (prev_value + new_value) / (prev_qty + new_qty) |
| Estimated Expiry | receipt_date + shelf_life_days |
| Warning Date (>7d life) | expiry - 7 |
| Warning Date (<=7d life) | expiry - 1 |
| Comparable Unit Price | price_per_pack / pack_content |
| Gross Sales | sum(qty x price) |
| Net Sales Revenue | gross - discounts - refunds |
| COGS (Inventory) | opening + purchases - closing - writeoffs |
| COGS (Recipe) | sum(consumed x cost_per_unit) |
| Gross Profit | net_sales - cogs |
| Operating Profit | gross_profit - operating_expenses |
| Net Profit | total_income - total_expenses |
| Net Profit Margin | (net_profit / net_sales) x 100 |
| Ingredient Cost/Serving | sum(ingredient_qty x cost_per_unit) |
| Gross Profit/Serving | price - ingredient_cost_per_serving |
| Gross Margin/Serving | (gross_profit_per_serving / price) x 100 |
| Waste Cost | sum(written_off_qty x cost_per_unit) |
| Period Change % | (change / prev_value) x 100 |
