---
name: business-solution
description: "Katsu Zushi F&B Business Management - ONE integrated skill for automatic inventory calculation, food expiry prediction and warnings, supplier price comparison, and financial reports (expenses, COGS, net profit analysis). Upload menu PDFs, purchase orders, daily sales reports, and expense records. All data shared across four features, persistent JSON storage, results displayed directly inside WorkBuddy. Triggers on inventory, expiry, supplier comparison, financial report, sales processing, stock deduction, PO registration, profit calculation, and Katsu Zushi business operations."
---

# Katsu Zushi Business Management

## Overview

This is ONE integrated business management skill for **Katsu Zushi** (F&B business). It provides four interconnected features that share the same data store:

1. **Automatic Inventory Calculation** - Recipe management, daily sales deduction, PO stock top-up, unit conversion
2. **Food Expiry Date Prediction and Warning System** - Batch-level tracking, FEFO rotation, 7-day/1-day/expired warnings
3. **Supplier Price Comparison** - Fair unit-price comparison, lowest-price identification, historical tracking
4. **Financial Reports, Expenses and Net Profit** - COGS, gross/operating/net profit, expense breakdowns, menu profitability

All results are displayed directly inside the WorkBuddy interface as tables, summaries, and warnings. No external website or dashboard is created.

## Critical Requirements

- All four features belong to ONE skill. Do not split into multiple skills.
- All data is shared across features via persistent JSON storage.
- Do not invent missing data (recipes, quantities, prices, sales, expiry dates).
- Do not claim data was saved unless the storage operation succeeds.
- If a capability is unavailable, explain the limitation and implement the closest alternative.
- Label estimated values as estimated. Never present estimates as confirmed.

## Data Storage Location

All persistent data is stored in JSON files under:
`C:/Users/user/.workbuddy-ai/skills/business-solution/data/`

Files:
- `recipes.json` - Menu items and ingredient quantities per serving
- `ingredients.json` - Ingredient definitions, units, pack sizes
- `inventory.json` - Current stock balances
- `batches.json` - Purchase batches with expiry info
- `suppliers.json` - Supplier details and historical prices
- `sales.json` - Daily sales records
- `transactions.json` - All inventory movements (deductions, additions, corrections)
- `expenses.json` - Business expense records
- `expiry_ref.json` - Shelf-life reference data from PDF
- `config.json` - Business config (name, currency, costing method, etc.)
- `processed_files.json` - File hashes for duplicate prevention

## Workflow Overview

When the user uploads documents or requests operations, follow this workflow:

1. **Identify** the uploaded document or requested action
2. **Extract** relevant data using the Read tool (for PDFs) or direct input
3. **Validate** ingredient names, quantities, units, dates, prices
4. **Check** existing records and transaction history for duplicates
5. **Process** using the appropriate script (`run_command` in scripts/)
6. **Display** results as formatted tables inside WorkBuddy
7. **Report** missing information, assumptions, and failures

---

## Initial Setup (First Time Use)

When the user uploads initial PDF documents (Menu, Purchase Order, Expiry Reference):

### Step 1: Read and Extract PDFs

Use the Read tool to read each PDF file:
- **Menu PDF**: Extract menu items, ingredient names, quantities per serving, units, serving sizes
- **PO PDF**: Extract ingredients, suppliers, purchase quantities, pack sizes, units, prices, dates
- **Expiry Reference PDF**: Extract shelf-life durations, storage conditions, ingredient categories

### Step 2: Initialize Data

Run the initialization script:
```bash
python scripts/katsu_db.py init
```
This creates the data directory and empty JSON structures.

### Step 3: Store Extracted Data

For each PDF type, run the corresponding script:
```bash
python scripts/inventory_manager.py add-recipes '<json_array>'
python scripts/inventory_manager.py process-po '<json_array>'
python scripts/expiry_manager.py load-reference '<json_array>'
```

Pass data as JSON strings. Each script validates, checks for duplicates, stores data, and returns a summary.

### Step 4: Confirm with User

After processing, show the user:
1. Extracted menu items and recipes
2. Initial inventory balances
3. Expiry tracking records (with missing expiry info flagged)
4. Supplier price comparisons
5. Assumptions that need confirmation
6. Additional data needed for accurate financial reports

**Ask for clarification** on any uncertain ingredient name matches, missing units, or ambiguous data. Do not assume.

---

## Feature 1: Automatic Inventory Calculation

### Ingredient and Recipe Management

For every recipe, record:
- Menu item name, ingredient name, quantity per serving, measurement unit, serving size, recipe version, last updated date

For every ingredient, record:
- Name, alternative names, standard unit, pack size, stock quantity, total available amount, purchase history, usage history, current balance, costing info, associated expiry batches

**Ingredient name matching**: Match names across menu, POs, sales, and inventory. If a match is uncertain, ASK the user.

### Daily Sales Processing

When the user uploads a daily sales report:

```bash
python scripts/inventory_manager.py process-sales '<json_array>'
```

The script:
1. Reads sales records (menu item, quantity sold, selling price, discounts, refunds)
2. Matches each menu item with stored recipe
3. Calculates total ingredient consumption: `usage = qty_sold x ingredient_qty_per_serving`
4. Deducts from inventory using FEFO (earliest expiry batch first)
5. Records deduction transactions
6. Returns updated stock balances and any shortages

**Rules:**
- If a menu item or recipe is missing, DO NOT invent ingredients. Ask the user.
- Use actual fulfilled sales quantities (exclude cancelled/refunded orders).
- Do not deduct ingredients twice for the same sale.
- Check `processed_files.json` to prevent duplicate processing.

### PO Stock Top-Up

When the user uploads a new Purchase Order:

```bash
python scripts/inventory_manager.py process-po '<json_array>'
```

The script:
1. Extracts ingredients, suppliers, quantities, pack sizes, units, prices, dates
2. Matches ingredients with existing inventory records
3. Converts quantities to standard units
4. Adds to existing stock (does NOT replace)
5. Creates separate batch per purchase for expiry tracking
6. Records purchase price and supplier info
7. Updates supplier price comparisons
8. Updates financial records

**Rules:**
- Only add stock when receipt is confirmed or user explicitly says to treat as received.
- If PO is not confirmed, record as pending stock.
- Do NOT replace existing stock with new quantity. Add to it.

### Unit and Quantity Rules (CRITICAL)

Every ingredient maintains its measurement unit and quantity correctly.

```
Ingredient: Panko Breadcrumbs
Pack size: 1,000 g per Qty
Current stock: 5 Qty
Total stock: 5 x 1,000 g = 5,000 g

If daily sales consume 1,500 g:
Remaining = 5,000 - 1,500 = 3,500 g
Display as: 3 Qty + 500 g remaining
```

**Rules:**
- Never round up stock quantities
- Never discard leftover grams, ml, or pieces
- Never treat 1 Qty as 1 g unless pack size explicitly states that
- Convert kg to g, L to ml when appropriate
- Convert boxes/bottles/packs only when their contents are known
- Never assume grams equal milliliters
- Support ingredients with different pack sizes per purchase
- If stock becomes negative, display shortage warning and missing quantity
- Do not silently set negative stock to zero

### Inventory Display

Display as a table directly inside WorkBuddy:

| Ingredient | Previous Stock | Stock Added | Stock Used | Current Stock | Status |
|---|---|---|---|---|---|

Show stock in both Qty and equivalent measurement amount. Maintain transaction history with date, ingredient, quantity, unit, type, source document, and reason.

```bash
python scripts/inventory_manager.py show
python scripts/inventory_manager.py history [ingredient_name]
```

---

## Feature 2: Food Expiry Date Prediction and Warning System

### Batch-Level Expiry Tracking

Each stock receipt from a PO creates a separate batch. Never merge batches with different expiry dates.

Record per batch:
- Ingredient, batch ID, supplier, PO reference, purchase date, receipt date, registration date, quantity received, pack size, unit, actual expiry date, estimated expiry date, shelf-life duration, storage conditions, remaining quantity, expiry status

### Expiry Date Priority

1. **Actual expiry date** from product or purchase documentation
2. **Shelf-life information** from the Expiry Reference PDF
3. **Reasonable estimate** supported by available info
4. **Ask user** if insufficient information

Use actual receipt date as starting point for shelf-life calculations. The PO upload date is the registration date, NOT necessarily the purchase/receipt/production date.

Never present estimated expiry as confirmed. Label clearly.

### Expiry Warning Rules

```bash
python scripts/expiry_manager.py check
python scripts/expiry_manager.py show
```

**Shelf life > 7 days:** Warning triggers 7 days before expiry date.
**Shelf life <= 7 days:** Warning triggers 1 day before expiry date.
**Already expired:** Immediate prominent warning, show batch and remaining quantity, mark for review and removal from usable inventory.

### FEFO Stock Rotation

When deducting ingredients, consume the eligible batch with the earliest expiry date first.

- Do not allocate normal sales usage to expired stock
- Flag expired stock for review and removal
- If sales records don't identify the actual batch, allocate by FEFO and record that allocation is estimated
- When a batch reaches zero, retain history but remove from available inventory
- Record expired/spoiled/discarded quantities and costs for financial reporting

### Expiry Display

| Ingredient | Batch | Remaining Stock | Expiry Date | Days Remaining | Status |

Clearly label expiry dates as "Confirmed" or "Estimated".

---

## Feature 3: Supplier Price Comparison

### Recording Supplier Prices

Every PO upload extracts and records:
- Ingredient, supplier, purchase date, PO ref, quantity, unit, pack size, price per pack, total cost, comparable unit price, discounts, delivery charges

Maintain ALL historical prices. Never overwrite previous prices.

```bash
python scripts/supplier_manager.py compare [ingredient_name]
python scripts/supplier_manager.py show-all
python scripts/supplier_manager.py savings <ingredient> <quantity> <unit>
```

### Fair Price Comparison

Compare equivalent products using the same standard measurement unit.

```
Supplier A: Panko 1,000g per pack, RM12/pack = RM0.012/g
Supplier B: Panko 500g per pack, RM7/pack = RM0.014/g
Conclusion: Supplier A offers lower unit price
```

**Rules:**
- Compare price per g, kg, ml, L, piece, or suitable standard unit
- Compare products with equivalent sizes and specs
- Identify differences in brand, grade, quality, packaging
- Account for discounts and delivery charges when data available
- State whether comparison uses listed or effective prices
- If data incomplete, explain limitation
- Do not invent missing supplier prices

### Lowest-Price Identification

For every ingredient:
1. Identify lowest comparable unit price supplier
2. Show all recorded supplier offers
3. Calculate difference between highest and lowest
4. Estimate potential savings for a specified quantity
5. If only one supplier, label "Only one supplier recorded"
6. Preserve historical prices for trend analysis

Display table:

| Ingredient | Supplier | Pack Size | Price per Pack | Unit Price | Ranking |

Do not auto-place orders. Provide recommendations for user review.

---

## Feature 4: Financial Reports, Expenses and Net Profit

### Financial Data Collection

**A. Sales Revenue** - Extracted from daily sales reports:
- Sales date, menu item, qty sold, selling price, gross sales, discounts, refunds, cancelled orders, net sales revenue, other income
- `Gross Sales = Total sales before discounts and refunds`
- `Net Sales Revenue = Gross Sales - Discounts - Refunds`
- Do not subtract discounts/refunds twice if the report already provides net sales

**B. Ingredient Costs:**
- Ingredient, qty consumed, cost per standard unit, total cost, purchase price history, inventory valuation, write-offs
- Use actual menu recipes, sales quantities, and recorded ingredient costs
- Prefer weighted-average cost unless user specifies otherwise
- Do NOT treat entire PO value as consumed cost in the same period
- Ingredients still in usable inventory remain as inventory value

**C. Other Business Expenses:**
```bash
python scripts/financial_manager.py add-expense '<json>'
python scripts/financial_manager.py list-expenses [category] [start_date] [end_date]
```

Record: date, category, description, payee, amount (RM), payment status, supporting doc

Default categories: Rent, Staff Salaries, Utilities (electricity/water/gas), Packaging, Delivery/Platform Commissions, Marketing, Equipment/Maintenance, Cleaning Supplies, Transportation, Other

User can add/edit/remove categories. Prevent duplicate expense records.

### Financial Calculations

```bash
python scripts/financial_manager.py report <type> [start_date] [end_date]
python scripts/financial_manager.py menu-profit
python scripts/financial_manager.py compare <period1> <period2>
```

1. **COGS** = Opening Inventory Value + Purchases + Eligible Costs - Closing Inventory Value (adjusted for write-offs). Alternatively, recipe-based consumption cost. Reconcile both methods. Never double-count.

2. **Gross Profit** = Net Sales Revenue - COGS

3. **Total Operating Expenses** = All recognized operating expenses (not in COGS)

4. **Operating Profit** = Gross Profit - Operating Expenses

5. **Net Profit** = Total Recognized Income - Total Recognized Expenses. If items missing, label "Preliminary Profit" or "Estimated Profit"

6. **Net Profit Margin (%)** = Net Profit / Net Sales Revenue x 100. If revenue is zero, display "N/A"

7. **Expense Breakdown** = Total amount and percentage per category

8. **Inventory Waste** = Costs of expired/spoiled/discarded ingredients. Include in adjustments without double-counting.

### Report Types

- Weekly, Monthly, Annual, Custom date-range
- Sales and profit comparisons
- Expense breakdowns
- Menu item profitability
- Ingredient cost analysis

Support natural-language requests. Use business local date/time. State reporting period and whether complete or in-progress.

### Financial Report Format

Display directly inside WorkBuddy:

**Part A: Financial Summary**

| Metric | Amount (RM) |
|---|---|
| Gross Sales | [amount] |
| Discounts and Refunds | [amount] |
| Net Sales Revenue | [amount] |
| Cost of Goods Sold | [amount] |
| Gross Profit | [amount] |
| Operating Expenses | [amount] |
| Operating Profit | [amount] |
| Other Income and Expenses | [amount] |
| Net Profit / Preliminary Profit | [amount] |
| Net Profit Margin | [percentage] |

If a figure cannot be calculated, display "Insufficient data" and explain why.

**Part B: Expense Breakdown**

| Expense Category | Total (RM) | Percentage of Expenses |
|---|---|---|

**Part C: Sales and Profit Trends** - Revenue, costs, expenses, gross/net profit, margin, changes vs previous period

**Part D: Menu Item Profitability**
- Estimated Ingredient Cost per Serving = Sum(ingredient_qty x cost_per_unit)
- Estimated Gross Profit per Serving = Selling Price - Ingredient Cost per Serving
- Estimated Gross Margin (%) = Gross Profit per Serving / Selling Price x 100
- Rank by gross profit and margin. Label as estimated, not net profit.

**Part E: Business Insights** - Largest expenses, sales/profit changes, price increases, high/low profit items, cost-saving opportunities, missing records. Separate facts from AI recommendations.

---

## Unified Interaction Examples

The user can use natural language for any operation:

**Inventory:**
- "Register this Purchase Order"
- "Process today's sales"
- "Show my current inventory"
- "How much Panko Breadcrumbs do I have left?"
- "Show my inventory deduction history"
- "Correct this stock quantity"

**Expiry:**
- "Which ingredients are expiring soon?"
- "Show all expired ingredients"
- "Check the expiry status of my current inventory"

**Supplier Comparison:**
- "Compare supplier prices for all ingredients"
- "Which supplier offers the lowest price for chicken breast?"
- "How much can I save by buying 10 kg of Panko from the cheapest supplier?"
- "Show supplier price changes over the last three months"

**Financial Reports:**
- "Generate my weekly financial report"
- "Show my monthly expenses and net profit"
- "Prepare my annual financial report"
- "Compare this month with last month"
- "Which menu items generate the highest gross profit?"
- "Which expense category costs me the most?"
- "Show my sales, ingredient costs, and profit trends"

All operations use the same stored records.

---

## Processing and Error-Prevention Rules

Before completing any operation:

1. Identify the uploaded document or requested action
2. Extract relevant data
3. Validate ingredient names, quantities, units, dates, and prices
4. Check existing records and transaction history
5. Perform calculations using correct formulas
6. Update persistent records only after validation
7. Confirm which operations were successfully completed
8. Report missing information, assumptions, and failures

**NEVER:**
- Fabricate recipes, sales figures, supplier prices, stock quantities, expenses, or expiry dates
- Deduct ingredients without a known recipe quantity
- Add stock without identifying quantity and unit
- Silently discard leftover stock quantities
- Present estimated expiry dates as confirmed
- Present preliminary profit as verified net profit
- Process the same file twice (check processed_files.json)
- Count the same ingredient cost in both COGS and operating expenses
- Treat revenue as profit
- Treat all purchases as expenses in the purchase period
- Set negative stock to zero silently

If a calculation depends on missing information, explain what is missing and request it.

---

## Duplicate Prevention

Before processing any file, check `processed_files.json`:
- Do not add the same PO stock twice
- Do not deduct ingredients twice for the same sales report
- Do not record the same expense twice
- Do not duplicate supplier price records for the same transaction
- Do not generate duplicate inventory movements

If corrections are needed, record correction transactions instead of silently changing historical records. If an operation fails, explain which records were updated and which were not.

---

## Important Accounting Rules

- Do not treat revenue as profit
- Do not automatically treat all purchases as expenses in the purchase period
- Do not count ingredient costs in both COGS and operating expenses
- Track unpaid invoices separately from paid expenses
- Distinguish cash flow from accounting profit
- Use a consistent accounting basis
- Clearly disclose missing data and assumptions
- Do not claim reports are audited or tax-compliant
- If net sales revenue is zero, display "N/A" for margin
- Label preliminary results clearly

---

## Persistent Storage and Limitations

This skill uses JSON file-based storage in the skill's `data/` directory. Data persists between conversations and skill executions as long as the files are not deleted.

**Limitations:**
- No automatic scheduled tasks. Expiry checks run when the skill is used, not automatically. Explain this to the user.
- No database server. Concurrent writes from multiple simultaneous processes may conflict.
- Storage capacity depends on available disk space.

If a required capability is unavailable, explain exactly what is missing and implement the closest supported alternative.

---

## Resources

### scripts/
- `katsu_db.py` - Core database layer (JSON storage, CRUD, transaction logging, duplicate detection)
- `inventory_manager.py` - Inventory calculations, unit conversion, stock deduction/top-up, display
- `expiry_manager.py` - Batch tracking, expiry date calculation, FEFO, warning generation
- `supplier_manager.py` - Supplier price records, unit-price comparison, lowest-price ID, savings
- `financial_manager.py` - Sales revenue, COGS, profit calculations, expense management, reports

### references/
- `data_model.md` - All JSON data structures and schemas
- `formulas.md` - Complete calculation formulas with examples
- `business_rules.md` - Business rules, unit rules, FEFO, warning thresholds, accounting rules
