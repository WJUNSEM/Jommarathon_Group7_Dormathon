#!/usr/bin/env python3
"""
Katsu Zushi Business Management - Core Database Layer
JSON-based persistent storage with CRUD operations, transaction logging, and duplicate detection.

Usage:
    python katsu_db.py init                      # Initialize data structures
    python katsu_db.py status                     # Show data storage status
    python katsu_db.py add-record <file> <json>   # Add a record to a data file
    python katsu_db.py check-file <hash>          # Check if file hash already processed
    python katsu_db.py register-file <name> <hash> <type> <count>  # Register processed file
    python katsu_db.py get-next-id <prefix>       # Get next sequential ID
"""

import json
import os
import sys
import hashlib
from datetime import datetime, date

# Data directory - persistent storage location
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# Define all data files and their default structure
DATA_FILES = {
    "config.json": {
        "business_name": "Katsu Zushi",
        "business_type": "F&B",
        "currency": "RM",
        "costing_method": "weighted_average",
        "timezone": "Asia/Kuala_Lumpur",
        "expense_categories": [
            "Rent",
            "Staff Salaries",
            "Utilities",
            "Packaging",
            "Delivery and Platform Commissions",
            "Marketing",
            "Equipment and Maintenance",
            "Cleaning Supplies",
            "Transportation",
            "Other Operating Expenses"
        ],
        "initialized": True,
        "init_date": None
    },
    "ingredients.json": {"ingredients": []},
    "recipes.json": {"recipes": []},
    "inventory.json": {"inventory": []},
    "batches.json": {"batches": []},
    "suppliers.json": {"suppliers": [], "price_records": []},
    "sales.json": {"sales": []},
    "transactions.json": {"transactions": []},
    "expenses.json": {"expenses": []},
    "expiry_ref.json": {"expiry_reference": []},
    "processed_files.json": {"processed_files": []},
    "write_offs.json": {"write_offs": []}
}

# Key for list-type files
LIST_KEYS = {
    "ingredients.json": "ingredients",
    "recipes.json": "recipes",
    "inventory.json": "inventory",
    "batches.json": "batches",
    "suppliers.json": None,  # Has two lists
    "sales.json": "sales",
    "transactions.json": "transactions",
    "expenses.json": "expenses",
    "expiry_ref.json": "expiry_reference",
    "processed_files.json": "processed_files",
    "write_offs.json": "write_offs"
}


def ensure_data_dir():
    """Create data directory if it doesn't exist."""
    os.makedirs(DATA_DIR, exist_ok=True)


def get_file_path(filename):
    """Get full path for a data file."""
    return os.path.join(DATA_DIR, filename)


def load_data(filename):
    """Load data from a JSON file. Returns empty structure if file doesn't exist."""
    path = get_file_path(filename)
    if not os.path.exists(path):
        default = DATA_FILES.get(filename, {})
        return json.loads(json.dumps(default))  # Deep copy
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"ERROR: Failed to load {filename}: {e}", file=sys.stderr)
        return json.loads(json.dumps(DATA_FILES.get(filename, {})))


def save_data(filename, data):
    """Save data to a JSON file. Returns True on success, False on failure."""
    ensure_data_dir()
    path = get_file_path(filename)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=json_serializer)
        return True
    except (IOError, TypeError) as e:
        print(f"ERROR: Failed to save {filename}: {e}", file=sys.stderr)
        return False


def json_serializer(obj):
    """Handle datetime/date serialization."""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def init_data():
    """Initialize all data files with default structures."""
    ensure_data_dir()
    now = datetime.now().isoformat()
    results = []
    
    for filename, default_data in DATA_FILES.items():
        path = get_file_path(filename)
        if os.path.exists(path):
            results.append(f"EXISTS: {filename}")
        else:
            # Set init_date for config
            if filename == "config.json":
                default_data["init_date"] = now
            if save_data(filename, default_data):
                results.append(f"CREATED: {filename}")
            else:
                results.append(f"FAILED: {filename}")
    
    print("=== Katsu Zushi Data Initialization ===")
    print(f"Data directory: {DATA_DIR}")
    for r in results:
        print(f"  {r}")
    print(f"\nAll data files initialized. Ready for business operations.")
    return True


def get_status():
    """Show status of all data files."""
    ensure_data_dir()
    print("=== Katsu Zushi Data Storage Status ===")
    print(f"Data directory: {DATA_DIR}")
    print()
    
    for filename in DATA_FILES:
        path = get_file_path(filename)
        if os.path.exists(path):
            data = load_data(filename)
            counts = []
            for key, val in data.items():
                if isinstance(val, list):
                    counts.append(f"{key}={len(val)}")
                elif isinstance(val, str) and len(val) < 50:
                    counts.append(f"{key}={val}")
            count_str = ", ".join(counts) if counts else "config"
            size = os.path.getsize(path)
            print(f"  {filename:25s} | {size:>8} bytes | {count_str}")
        else:
            print(f"  {filename:25s} | NOT INITIALIZED")
    
    print()
    print("Run 'python katsu_db.py init' to initialize missing files.")


def add_record(filename, record, list_key=None):
    """Add a record to a list within a data file. Returns True on success."""
    if list_key is None:
        list_key = LIST_KEYS.get(filename)
    
    if list_key is None:
        print(f"ERROR: No list key for {filename}. Use save_data() directly.", file=sys.stderr)
        return False
    
    data = load_data(filename)
    if list_key not in data:
        data[list_key] = []
    data[list_key].append(record)
    return save_data(filename, data)


def add_record_to_sublist(filename, sublist_key, record):
    """Add a record to a specific sublist (e.g., suppliers.json has 'suppliers' and 'price_records')."""
    data = load_data(filename)
    if sublist_key not in data:
        data[sublist_key] = []
    data[sublist_key].append(record)
    return save_data(filename, data)


def get_next_id(prefix):
    """Generate the next sequential ID for a given prefix."""
    # Map prefix to the file and key to count existing records
    id_map = {
        "ing": ("ingredients.json", "ingredients"),
        "rec": ("recipes.json", "recipes"),
        "bat": ("batches.json", "batches"),
        "sup": ("suppliers.json", "suppliers"),
        "pr": ("suppliers.json", "price_records"),
        "sale": ("sales.json", "sales"),
        "txn": ("transactions.json", "transactions"),
        "exp": ("expenses.json", "expenses"),
        "exp_ref": ("expiry_ref.json", "expiry_reference"),
        "pf": ("processed_files.json", "processed_files"),
        "wo": ("write_offs.json", "write_offs"),
    }
    
    if prefix not in id_map:
        return f"{prefix}_001"
    
    filename, key = id_map[prefix]
    data = load_data(filename)
    records = data.get(key, [])
    next_num = len(records) + 1
    return f"{prefix}_{next_num:03d}"


def compute_file_hash(file_path):
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    try:
        with open(file_path, 'rb') as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()
    except IOError:
        return None


def check_file_processed(file_hash):
    """Check if a file with this hash has already been processed."""
    data = load_data("processed_files.json")
    for pf in data.get("processed_files", []):
        if pf.get("file_hash") == file_hash:
            return True, pf
    return False, None


def register_processed_file(file_name, file_hash, file_type, records_created, status="success"):
    """Register a processed file to prevent duplicate processing."""
    record = {
        "id": get_next_id("pf"),
        "file_name": file_name,
        "file_hash": file_hash,
        "file_type": file_type,
        "processed_date": datetime.now().isoformat(),
        "records_created": records_created,
        "status": status
    }
    return add_record("processed_files.json", record, "processed_files")


def find_ingredient(name, fuzzy=True):
    """Find an ingredient by name, including alternative names."""
    data = load_data("ingredients.json")
    name_lower = name.lower().strip()
    
    for ing in data.get("ingredients", []):
        if ing["name"].lower().strip() == name_lower:
            return ing
        if fuzzy:
            for alt in ing.get("alternative_names", []):
                if alt.lower().strip() == name_lower:
                    return ing
    return None


def find_recipe(menu_item):
    """Find a recipe by menu item name."""
    data = load_data("recipes.json")
    item_lower = menu_item.lower().strip()
    for rec in data.get("recipes", []):
        if rec["menu_item"].lower().strip() == item_lower:
            return rec
    return None


def find_supplier(name):
    """Find a supplier by name."""
    data = load_data("suppliers.json")
    name_lower = name.lower().strip()
    for sup in data.get("suppliers", []):
        if sup["name"].lower().strip() == name_lower:
            return sup
    return None


def get_all_batches(ingredient_name=None, active_only=True):
    """Get all batches, optionally filtered by ingredient and active status."""
    data = load_data("batches.json")
    batches = data.get("batches", [])
    
    result = []
    for bat in batches:
        if active_only and not bat.get("active", True):
            continue
        if ingredient_name and bat.get("ingredient_name", "").lower() != ingredient_name.lower():
            continue
        result.append(bat)
    
    # Sort by expiry date (earliest first) for FEFO
    result.sort(key=lambda b: b.get("actual_expiry_date") or b.get("estimated_expiry_date") or "9999-12-31")
    return result


def get_all_transactions(ingredient_name=None, limit=None):
    """Get all transactions, optionally filtered by ingredient."""
    data = load_data("transactions.json")
    txns = data.get("transactions", [])
    
    if ingredient_name:
        name_lower = ingredient_name.lower()
        txns = [t for t in txns if t.get("ingredient_name", "").lower() == name_lower]
    
    # Sort by date descending (most recent first)
    txns.sort(key=lambda t: t.get("date", ""), reverse=True)
    
    if limit:
        txns = txns[:limit]
    
    return txns


def get_all_sales(start_date=None, end_date=None):
    """Get all sales records, optionally filtered by date range."""
    data = load_data("sales.json")
    sales = data.get("sales", [])
    
    if start_date:
        sales = [s for s in sales if s.get("sales_date", "") >= start_date]
    if end_date:
        sales = [s for s in sales if s.get("sales_date", "") <= end_date]
    
    return sales


def get_all_expenses(start_date=None, end_date=None, category=None):
    """Get all expense records, optionally filtered."""
    data = load_data("expenses.json")
    expenses = data.get("expenses", [])
    
    if start_date:
        expenses = [e for e in expenses if e.get("date", "") >= start_date]
    if end_date:
        expenses = [e for e in expenses if e.get("date", "") <= end_date]
    if category:
        expenses = [e for e in expenses if e.get("category", "").lower() == category.lower()]
    
    return expenses


def get_all_price_records(ingredient_name=None):
    """Get all price records, optionally filtered by ingredient."""
    data = load_data("suppliers.json")
    records = data.get("price_records", [])
    
    if ingredient_name:
        name_lower = ingredient_name.lower()
        records = [r for r in records if r.get("ingredient_name", "").lower() == name_lower]
    
    # Sort by date descending
    records.sort(key=lambda r: r.get("purchase_date", ""), reverse=True)
    return records


def get_expiry_reference(ingredient_name=None, category=None):
    """Get expiry reference data, optionally filtered."""
    data = load_data("expiry_ref.json")
    refs = data.get("expiry_reference", [])
    
    if ingredient_name:
        name_lower = ingredient_name.lower()
        refs = [r for r in refs if r.get("ingredient_name", "").lower() == name_lower]
    if category:
        cat_lower = category.lower()
        refs = [r for r in refs if r.get("ingredient_category", "").lower() == cat_lower]
    
    return refs


def get_config():
    """Get business configuration."""
    return load_data("config.json")


def update_inventory_record(ingredient_name, prev_qty, prev_amount, added_qty, added_amount, used_qty, used_amount):
    """Update or create an inventory record for an ingredient."""
    data = load_data("inventory.json")
    
    # Find existing record
    found = False
    for inv in data.get("inventory", []):
        if inv["ingredient_name"].lower() == ingredient_name.lower():
            inv["previous_stock_qty"] = prev_qty
            inv["previous_stock_amount"] = prev_amount
            inv["stock_added_qty"] = added_qty
            inv["stock_added_amount"] = added_amount
            inv["stock_used_qty"] = used_qty
            inv["stock_used_amount"] = used_amount
            inv["current_stock_qty"] = prev_qty + added_qty - used_qty
            inv["current_stock_amount"] = prev_amount + added_amount - used_amount
            inv["last_updated"] = datetime.now().isoformat()
            found = True
            break
    
    if not found:
        new_record = {
            "ingredient_name": ingredient_name,
            "previous_stock_qty": prev_qty,
            "previous_stock_amount": prev_amount,
            "stock_added_qty": added_qty,
            "stock_added_amount": added_amount,
            "stock_used_qty": used_qty,
            "stock_used_amount": used_amount,
            "current_stock_qty": prev_qty + added_qty - used_qty,
            "current_stock_amount": prev_amount + added_amount - used_amount,
            "last_updated": datetime.now().isoformat()
        }
        data.setdefault("inventory", []).append(new_record)
    
    return save_data("inventory.json", data)


def record_transaction(ingredient_name, quantity, unit, txn_type, source, reason, 
                        batch_id=None, value=None, allocation_method=None, allocation_estimated=None):
    """Record a transaction in the transaction log."""
    record = {
        "id": get_next_id("txn"),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "ingredient_name": ingredient_name,
        "quantity": quantity,
        "unit": unit,
        "transaction_type": txn_type,
        "source_document": source,
        "reason": reason,
        "batch_id": batch_id,
        "value": value,
        "allocation_method": allocation_method,
        "allocation_estimated": allocation_estimated,
        "created": datetime.now().isoformat()
    }
    return add_record("transactions.json", record, "transactions")


def main():
    if len(sys.argv) < 2:
        print("Usage: python katsu_db.py <command> [args]")
        print("Commands:")
        print("  init                                          Initialize data structures")
        print("  status                                        Show data storage status")
        print("  add-record <file> <json> [list_key]           Add a record to a data file")
        print("  check-file <hash>                             Check if file hash already processed")
        print("  register-file <name> <hash> <type> <count>    Register processed file")
        print("  get-next-id <prefix>                          Get next sequential ID")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "init":
        init_data()
    
    elif command == "status":
        get_status()
    
    elif command == "add-record":
        if len(sys.argv) < 4:
            print("Usage: python katsu_db.py add-record <filename> <json> [list_key]")
            sys.exit(1)
        filename = sys.argv[2]
        record = json.loads(sys.argv[3])
        list_key = sys.argv[4] if len(sys.argv) > 4 else None
        if add_record(filename, record, list_key):
            print(f"Record added to {filename}")
        else:
            print(f"FAILED to add record to {filename}")
            sys.exit(1)
    
    elif command == "check-file":
        if len(sys.argv) < 3:
            print("Usage: python katsu_db.py check-file <hash>")
            sys.exit(1)
        file_hash = sys.argv[2]
        processed, info = check_file_processed(file_hash)
        if processed:
            print(json.dumps({"processed": True, "info": info}))
        else:
            print(json.dumps({"processed": False}))
    
    elif command == "register-file":
        if len(sys.argv) < 6:
            print("Usage: python katsu_db.py register-file <name> <hash> <type> <count>")
            sys.exit(1)
        file_name = sys.argv[2]
        file_hash = sys.argv[3]
        file_type = sys.argv[4]
        count = int(sys.argv[5])
        if register_processed_file(file_name, file_hash, file_type, count):
            print(f"File registered: {file_name}")
        else:
            print("FAILED to register file")
            sys.exit(1)
    
    elif command == "get-next-id":
        if len(sys.argv) < 3:
            print("Usage: python katsu_db.py get-next-id <prefix>")
            sys.exit(1)
        prefix = sys.argv[2]
        print(get_next_id(prefix))
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
