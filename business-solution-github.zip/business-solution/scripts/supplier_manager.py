#!/usr/bin/env python3
"""
Katsu Zushi - Supplier Comparison Manager
Handles supplier price records, fair unit-price comparison, lowest-price identification,
savings calculation, and historical price tracking.

Usage:
    python supplier_manager.py compare [ingredient_name]   # Compare prices for ingredient(s)
    python supplier_manager.py show-all                     # Show all supplier prices
    python supplier_manager.py savings <ingredient> <qty> <unit>  # Calculate potential savings
    python supplier_manager.py history <ingredient>        # Show price history
    python supplier_manager.py add-supplier '<json>'        # Add supplier record
"""

import json
import sys
import os
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import katsu_db


def compare_prices(ingredient_name=None):
    """
    Compare supplier prices for all or specific ingredients.
    Shows comparable unit price and identifies the lowest.
    """
    if ingredient_name:
        ingredients = [ingredient_name]
    else:
        # Get all unique ingredient names from price records
        price_data = katsu_db.load_data("suppliers.json")
        all_ingredients = set()
        for pr in price_data.get("price_records", []):
            all_ingredients.add(pr.get("ingredient_name", ""))
        ingredients = sorted(all_ingredients)
    
    if not ingredients:
        print("=== Supplier Price Comparison ===")
        print("No supplier price records found. Upload a Purchase Order to record prices.")
        return
    
    print("=== Supplier Price Comparison ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    for ing in ingredients:
        records = katsu_db.get_all_price_records(ingredient_name=ing)
        
        if not records:
            continue
        
        # Group by supplier (get latest price per supplier)
        supplier_prices = {}
        for r in records:
            supplier = r.get("supplier", "")
            if supplier not in supplier_prices or r.get("purchase_date", "") > supplier_prices[supplier].get("purchase_date", ""):
                supplier_prices[supplier] = r
        
        if len(supplier_prices) == 1:
            supplier = list(supplier_prices.keys())[0]
            r = supplier_prices[supplier]
            print(f"📌 {ing}")
            print(f"  Only one supplier recorded: {supplier}")
            print(f"  Pack: {r.get('pack_size', 'N/A')}")
            print(f"  Price per pack: RM{r.get('price_per_pack', 0):.2f}")
            unit_price = r.get("comparable_unit_price", 0)
            unit = r.get("comparable_unit", "g")
            print(f"  Unit price: RM{unit_price:.4f}/{unit}")
            print(f"  Purchase date: {r.get('purchase_date', '')}")
            print(f"  PO: {r.get('po_reference', '')}")
            print()
            continue
        
        # Multiple suppliers - compare
        print(f"📊 {ing} - {len(supplier_prices)} suppliers")
        print()
        
        # Sort by unit price (lowest first)
        sorted_suppliers = sorted(supplier_prices.items(), 
                                   key=lambda x: x[1].get("comparable_unit_price", float('inf')))
        
        # Table header
        print(f"  {'Supplier':<20} | {'Pack Size':<25} | {'Price/Pack':<12} | {'Unit Price':<15} | {'Rank'}")
        print("  " + "-" * 90)
        
        lowest_price = sorted_suppliers[0][1].get("comparable_unit_price", 0)
        highest_price = sorted_suppliers[-1][1].get("comparable_unit_price", 0)
        price_diff = highest_price - lowest_price
        
        for rank, (supplier, r) in enumerate(sorted_suppliers, 1):
            pack = r.get("pack_size", "N/A")
            price_pack = r.get("price_per_pack", 0)
            unit_price = r.get("comparable_unit_price", 0)
            unit = r.get("comparable_unit", "g")
            
            rank_str = f"#{rank}" + (" ★ LOWEST" if rank == 1 else "")
            print(f"  {supplier:<20} | {pack:<25} | RM{price_pack:<10.2f} | RM{unit_price:.4f}/{unit:<8} | {rank_str}")
        
        print()
        print(f"  Price difference: RM{price_diff:.4f}/{sorted_suppliers[0][1].get('comparable_unit', 'g')}")
        
        if price_diff > 0 and lowest_price > 0:
            pct_diff = (price_diff / lowest_price) * 100
            print(f"  Cheapest is {pct_diff:.1f}% cheaper than most expensive")
        
        print(f"  Recommended: {sorted_suppliers[0][0]} (lowest unit price)")
        print()
    
    # Summary of all ingredients
    if not ingredient_name:
        print("=== Lowest Price Summary ===")
        print(f"{'Ingredient':<25} | {'Best Supplier':<20} | {'Unit Price':<15} | {'Savings vs Highest'}")
        print("-" * 85)
        
        for ing in ingredients:
            records = katsu_db.get_all_price_records(ingredient_name=ing)
            if not records:
                continue
            
            supplier_prices = {}
            for r in records:
                supplier = r.get("supplier", "")
                if supplier not in supplier_prices or r.get("purchase_date", "") > supplier_prices[supplier].get("purchase_date", ""):
                    supplier_prices[supplier] = r
            
            if len(supplier_prices) >= 2:
                sorted_suppliers = sorted(supplier_prices.items(),
                                           key=lambda x: x[1].get("comparable_unit_price", float('inf')))
                best = sorted_suppliers[0]
                worst = sorted_suppliers[-1]
                savings = worst[1].get("comparable_unit_price", 0) - best[1].get("comparable_unit_price", 0)
                unit = best[1].get("comparable_unit", "g")
                print(f"{ing:<25} | {best[0]:<20} | RM{best[1].get('comparable_unit_price', 0):.4f}/{unit:<8} | RM{savings:.4f}/{unit}")
            else:
                supplier = list(supplier_prices.keys())[0]
                r = supplier_prices[supplier]
                unit = r.get("comparable_unit", "g")
                print(f"{ing:<25} | {supplier:<20} | RM{r.get('comparable_unit_price', 0):.4f}/{unit:<8} | Only one supplier")


def show_all_prices():
    """Show all supplier price records."""
    price_data = katsu_db.load_data("suppliers.json")
    records = price_data.get("price_records", [])
    
    print("=== All Supplier Price Records ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"Total records: {len(records)}")
    print()
    
    if not records:
        print("No price records found.")
        return
    
    # Sort by ingredient, then by date descending
    records.sort(key=lambda r: (r.get("ingredient_name", ""), r.get("purchase_date", "")), reverse=False)
    
    print(f"{'Ingredient':<20} | {'Supplier':<20} | {'Date':<12} | {'Pack':<25} | {'Price/Pack':<11} | {'Unit Price':<15} | {'PO'}")
    print("-" * 140)
    
    for r in records:
        print(f"{r.get('ingredient_name', ''):<20} | {r.get('supplier', ''):<20} | {r.get('purchase_date', ''):<12} | "
              f"{r.get('pack_size', ''):<25} | RM{r.get('price_per_pack', 0):<9.2f} | "
              f"RM{r.get('comparable_unit_price', 0):.4f}/{r.get('comparable_unit', 'g'):<8} | {r.get('po_reference', '')}")


def calculate_savings(ingredient, quantity, unit):
    """
    Calculate potential savings by buying from cheapest supplier.
    """
    records = katsu_db.get_all_price_records(ingredient_name=ingredient)
    
    if not records:
        print(f"No supplier price records found for '{ingredient}'.")
        return
    
    # Group by supplier (latest price)
    supplier_prices = {}
    for r in records:
        supplier = r.get("supplier", "")
        if supplier not in supplier_prices or r.get("purchase_date", "") > supplier_prices[supplier].get("purchase_date", ""):
            supplier_prices[supplier] = r
    
    print(f"=== Savings Calculation: {ingredient} ===")
    print(f"Purchase quantity: {quantity} {unit}")
    print()
    
    if len(supplier_prices) == 1:
        supplier = list(supplier_prices.keys())[0]
        r = supplier_prices[supplier]
        print(f"Only one supplier recorded: {supplier}")
        print(f"Unit price: RM{r.get('comparable_unit_price', 0):.4f}/{r.get('comparable_unit', 'g')}")
        total = r.get("comparable_unit_price", 0) * float(quantity)
        print(f"Total cost: RM{total:.2f}")
        print("Cannot calculate savings - only one supplier.")
        return
    
    sorted_suppliers = sorted(supplier_prices.items(),
                               key=lambda x: x[1].get("comparable_unit_price", float('inf')))
    
    cheapest = sorted_suppliers[0]
    most_expensive = sorted_suppliers[-1]
    
    cheapest_unit = cheapest[1].get("comparable_unit_price", 0)
    expensive_unit = most_expensive[1].get("comparable_unit_price", 0)
    
    cheapest_total = cheapest_unit * float(quantity)
    expensive_total = expensive_unit * float(quantity)
    savings = expensive_total - cheapest_total
    
    print(f"{'Supplier':<20} | {'Unit Price':<15} | {'Total Cost':<12} | {'vs Cheapest'}")
    print("-" * 70)
    
    for supplier, r in sorted_suppliers:
        unit_price = r.get("comparable_unit_price", 0)
        total = unit_price * float(quantity)
        diff = total - cheapest_total
        diff_str = f"+RM{diff:.2f}" if diff > 0 else "★ CHEAPEST"
        print(f"{supplier:<20} | RM{unit_price:.4f}/{r.get('comparable_unit', 'g'):<8} | RM{total:<10.2f} | {diff_str}")
    
    print()
    print(f"Cheapest supplier: {cheapest[0]}")
    print(f"Most expensive: {most_expensive[0]}")
    print(f"Potential savings: RM{savings:.2f} ({(savings/expensive_total*100) if expensive_total > 0 else 0:.1f}% savings)")
    print(f"\nNote: This is a recommendation for review. No order will be placed automatically.")


def show_price_history(ingredient):
    """Show price history for an ingredient across all suppliers."""
    records = katsu_db.get_all_price_records(ingredient_name=ingredient)
    
    print(f"=== Price History: {ingredient} ===")
    print()
    
    if not records:
        print(f"No price records found for '{ingredient}'.")
        return
    
    # Sort by date ascending (oldest first)
    records.sort(key=lambda r: r.get("purchase_date", ""))
    
    # Group by supplier
    by_supplier = {}
    for r in records:
        supplier = r.get("supplier", "")
        if supplier not in by_supplier:
            by_supplier[supplier] = []
        by_supplier[supplier].append(r)
    
    print(f"{'Date':<12} | {'Supplier':<20} | {'Pack Size':<25} | {'Price/Pack':<11} | {'Unit Price':<15} | {'PO':<15}")
    print("-" * 105)
    
    for r in records:
        print(f"{r.get('purchase_date', ''):<12} | {r.get('supplier', ''):<20} | {r.get('pack_size', ''):<25} | "
              f"RM{r.get('price_per_pack', 0):<9.2f} | RM{r.get('comparable_unit_price', 0):.4f}/{r.get('comparable_unit', 'g'):<8} | "
              f"{r.get('po_reference', ''):<15}")
    
    # Show price changes
    print()
    print("=== Price Changes ===")
    
    for supplier, sup_records in by_supplier.items():
        if len(sup_records) < 2:
            continue
        
        print(f"\n{supplier}:")
        prev_price = None
        for r in sup_records:
            current_price = r.get("comparable_unit_price", 0)
            if prev_price is not None and current_price != prev_price:
                change = current_price - prev_price
                pct = (change / prev_price * 100) if prev_price > 0 else 0
                direction = "↑ INCREASED" if change > 0 else "↓ DECREASED"
                print(f"  {r.get('purchase_date', '')}: {direction} by RM{abs(change):.4f} ({abs(pct):.1f}%) "
                      f"(from RM{prev_price:.4f} to RM{current_price:.4f})")
            prev_price = current_price


def add_supplier(supplier_json):
    """Add a new supplier record."""
    data = json.loads(supplier_json) if isinstance(supplier_json, str) else supplier_json
    
    name = data.get("name", "").strip()
    if not name:
        print("ERROR: Supplier name is required")
        return False
    
    existing = katsu_db.find_supplier(name)
    if existing:
        print(f"Supplier '{name}' already exists (ID: {existing['id']})")
        return True
    
    supplier = {
        "id": katsu_db.get_next_id("sup"),
        "name": name,
        "contact": data.get("contact"),
        "address": data.get("address"),
        "phone": data.get("phone"),
        "created": datetime.now().isoformat()
    }
    
    if katsu_db.add_record_to_sublist("suppliers.json", "suppliers", supplier):
        print(f"✓ Supplier added: {name} (ID: {supplier['id']})")
    else:
        print(f"FAILED to add supplier: {name}")
    
    return True


def main():
    if len(sys.argv) < 2:
        print("Usage: python supplier_manager.py <command> [args]")
        print("Commands:")
        print("  compare [ingredient]                       Compare supplier prices")
        print("  show-all                                    Show all price records")
        print("  savings <ingredient> <qty> <unit>          Calculate potential savings")
        print("  history <ingredient>                        Show price history")
        print("  add-supplier '<json>'                       Add supplier record")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "compare":
        ingredient = sys.argv[2] if len(sys.argv) > 2 else None
        compare_prices(ingredient)
    
    elif command == "show-all":
        show_all_prices()
    
    elif command == "savings":
        if len(sys.argv) < 5:
            print("Usage: python supplier_manager.py savings <ingredient> <quantity> <unit>")
            sys.exit(1)
        calculate_savings(sys.argv[2], float(sys.argv[3]), sys.argv[4])
    
    elif command == "history":
        if len(sys.argv) < 3:
            print("Usage: python supplier_manager.py history <ingredient>")
            sys.exit(1)
        show_price_history(sys.argv[2])
    
    elif command == "add-supplier":
        if len(sys.argv) < 3:
            print("Usage: python supplier_manager.py add-supplier '<json>'")
            sys.exit(1)
        add_supplier(sys.argv[2])
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
