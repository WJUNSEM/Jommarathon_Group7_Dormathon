#!/usr/bin/env python3
"""Load expiry reference data and recipes from Menu Katsu Zushi PDF."""

import json
import sys
import os
import hashlib
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "scripts"))
import katsu_db

# ============================================================================
# 1. EXPIRY REFERENCE DATA
# ============================================================================
# Shelf life converted to days (conservative end of range)
# For items with multiple storage conditions, primary condition used

expiry_refs = [
    # Proteins & Seafood
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Salmon (Sashimi-grade)", "shelf_life_days": 2, "storage_conditions": "Refrigerated", "notes": "1-2 days refrigerated"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Tuna (Sashimi-grade)", "shelf_life_days": 2, "storage_conditions": "Refrigerated", "notes": "1-2 days refrigerated; includes scraps"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Yellowtail (Hamachi)", "shelf_life_days": 2, "storage_conditions": "Refrigerated", "notes": "1-2 days refrigerated"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Fresh Sea Urchin (Uni)", "shelf_life_days": 2, "storage_conditions": "Refrigerated", "notes": "1-2 days refrigerated"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Soft Shell Crab (Flash-frozen)", "shelf_life_days": 210, "storage_conditions": "Frozen", "notes": "6-8 months frozen; 1-2 days thawed"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Imitation Crab Stick (Surimi)", "shelf_life_days": 14, "storage_conditions": "Refrigerated", "notes": "2 weeks unopened refrigerated; 3-5 days opened"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Pork Loin/Fillet", "shelf_life_days": 4, "storage_conditions": "Refrigerated", "notes": "3-4 days refrigerated; for Tonkatsu"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Chicken Breast/Thigh", "shelf_life_days": 4, "storage_conditions": "Refrigerated", "notes": "3-4 days refrigerated"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Raw Shrimp", "shelf_life_days": 3, "storage_conditions": "Refrigerated", "notes": "2-3 days refrigerated; for Chawanmushi"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Kamaboko (Fish Cake)", "shelf_life_days": 28, "storage_conditions": "Refrigerated", "notes": "3-4 weeks unopened; 3-5 days opened"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Fresh Eggs", "shelf_life_days": 28, "storage_conditions": "Refrigerated", "notes": "3-4 weeks refrigerated; for breading and Chawanmushi"},
    {"ingredient_category": "Proteins & Seafood", "ingredient_name": "Silken Tofu", "shelf_life_days": 5, "storage_conditions": "Refrigerated", "notes": "3-5 days opened in water; for Miso Soup"},

    # Produce & Fresh
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Avocado", "shelf_life_days": 3, "storage_conditions": "Refrigerated", "notes": "2-3 days ripe refrigerated; hours once cut"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Cucumber", "shelf_life_days": 7, "storage_conditions": "Refrigerated", "notes": "5-7 days refrigerated"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Scallions / Spring Onions", "shelf_life_days": 7, "storage_conditions": "Refrigerated", "notes": "5-7 days refrigerated"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Fresh Lemons", "shelf_life_days": 21, "storage_conditions": "Refrigerated", "notes": "2-3 weeks refrigerated; for Lemon Tea"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Carrots", "shelf_life_days": 28, "storage_conditions": "Refrigerated", "notes": "3-4 weeks refrigerated; for Curry"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Potatoes", "shelf_life_days": 60, "storage_conditions": "Cool, dark pantry", "notes": "1-2 months cool dark pantry; for Curry"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Yellow Onions", "shelf_life_days": 60, "storage_conditions": "Cool, dark pantry", "notes": "1-2 months cool dark pantry; for Curry"},
    {"ingredient_category": "Produce & Fresh", "ingredient_name": "Shiitake Mushrooms", "shelf_life_days": 7, "storage_conditions": "Refrigerated", "notes": "5-7 days refrigerated"},

    # Pantry & Dry Goods
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Short-Grain Japanese Sushi Rice", "shelf_life_days": 365, "storage_conditions": "Dry pantry", "notes": "1+ years dry pantry; 12 hours cooked room temp"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Nori (Roasted Seaweed Sheets)", "shelf_life_days": 270, "storage_conditions": "Airtight container", "notes": "6-12 months airtight container"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Panko Breadcrumbs", "shelf_life_days": 270, "storage_conditions": "Dry pantry", "notes": "6-12 months dry pantry"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "All-Purpose / Tempura Flour", "shelf_life_days": 270, "storage_conditions": "Dry pantry", "notes": "6-12 months dry pantry"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Frozen Udon Noodles", "shelf_life_days": 270, "storage_conditions": "Frozen", "notes": "6-12 months frozen"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Frozen Edamame", "shelf_life_days": 270, "storage_conditions": "Frozen", "notes": "6-12 months frozen"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Wakame (Dried Seaweed)", "shelf_life_days": 365, "storage_conditions": "Dry pantry", "notes": "1+ years dry pantry; for Miso Soup"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Dried Shiitake Mushrooms", "shelf_life_days": 365, "storage_conditions": "Dry pantry", "notes": "1+ years dry pantry"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "White Sesame Seeds", "shelf_life_days": 180, "storage_conditions": "Pantry", "notes": "6 months pantry; 1 year refrigerated"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Green Tea Leaves / Sencha", "shelf_life_days": 270, "storage_conditions": "Airtight container", "notes": "6-12 months airtight container"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Black Tea Leaves/Bags", "shelf_life_days": 545, "storage_conditions": "Pantry", "notes": "1-2 years pantry; for Lemon Tea"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "White Sugar", "shelf_life_days": 3650, "storage_conditions": "Pantry", "notes": "Indefinite pantry"},
    {"ingredient_category": "Pantry & Dry Goods", "ingredient_name": "Sea Salt / Kosher Salt", "shelf_life_days": 3650, "storage_conditions": "Pantry", "notes": "Indefinite pantry"},

    # Seasonings & Liquids
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Soy Sauce (Shoyu)", "shelf_life_days": 912, "storage_conditions": "Pantry", "notes": "2-3 years unopened; 6 months opened"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Rice Vinegar", "shelf_life_days": 730, "storage_conditions": "Pantry", "notes": "2 years pantry; for Sushi Rice"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Mirin", "shelf_life_days": 545, "storage_conditions": "Pantry", "notes": "1-2 years pantry"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Cooking Sake", "shelf_life_days": 365, "storage_conditions": "Pantry", "notes": "1 year pantry"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Dashi Stock / Kombu & Bonito", "shelf_life_days": 365, "storage_conditions": "Dry pantry", "notes": "1 year dry; 3-4 days prepared broth refrigerated"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Miso Paste", "shelf_life_days": 365, "storage_conditions": "Refrigerated", "notes": "1 year refrigerated; Red/White"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Japanese Curry Blocks (Roux)", "shelf_life_days": 365, "storage_conditions": "Pantry", "notes": "1 year unopened; 3 months opened refrigerated"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Kewpie Mayonnaise", "shelf_life_days": 270, "storage_conditions": "Refrigerated", "notes": "6-9 months unopened; 2 months opened"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Sriracha / Chili Oil", "shelf_life_days": 545, "storage_conditions": "Pantry", "notes": "1-2 years pantry; 6 months opened; for Spicy Tuna"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Tonkatsu Sauce", "shelf_life_days": 545, "storage_conditions": "Pantry", "notes": "1-2 years unopened; 6 months opened refrigerated"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Wasabi Paste", "shelf_life_days": 365, "storage_conditions": "Refrigerated", "notes": "1 year powder/unopened tube; 1-2 months opened"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Pickled Ginger (Gari)", "shelf_life_days": 365, "storage_conditions": "Pantry", "notes": "1 year unopened; 3-4 months opened refrigerated"},
    {"ingredient_category": "Seasonings & Liquids", "ingredient_name": "Frying Oil (Canola/Vegetable)", "shelf_life_days": 365, "storage_conditions": "Pantry", "notes": "1 year unopened; degrades quickly after heating"},

    # Prepared / Compound ingredients (for recipe matching)
    {"ingredient_category": "Prepared", "ingredient_name": "Prepared Sushi Rice", "shelf_life_days": 0, "storage_conditions": "Room temperature", "notes": "12 hours at room temp; made from Short-Grain Japanese Sushi Rice"},
    {"ingredient_category": "Prepared", "ingredient_name": "Prepared Dashi Broth", "shelf_life_days": 4, "storage_conditions": "Refrigerated", "notes": "3-4 days refrigerated; made from Dashi Stock"},
    {"ingredient_category": "Utility", "ingredient_name": "Filtered Water", "shelf_life_days": 0, "storage_conditions": "N/A", "notes": "No expiry; utility ingredient"},
]

# ============================================================================
# 2. MENU RECIPES
# ============================================================================

recipes = [
    # Sashimi (5-piece)
    {
        "menu_item": "Salmon (Sake) Sashimi",
        "serving_size": "5 pieces",
        "selling_price": 28,
        "ingredients": [
            {"name": "Raw Salmon (Sashimi-grade)", "quantity": 80, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Tuna (Maguro) Sashimi",
        "serving_size": "5 pieces",
        "selling_price": 32,
        "ingredients": [
            {"name": "Raw Tuna (Sashimi-grade)", "quantity": 80, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Yellowtail (Hamachi) Sashimi",
        "serving_size": "5 pieces",
        "selling_price": 38,
        "ingredients": [
            {"name": "Raw Yellowtail (Hamachi)", "quantity": 80, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Sea Urchin (Uni) Sashimi",
        "serving_size": "5 pieces",
        "selling_price": 65,
        "ingredients": [
            {"name": "Fresh Sea Urchin (Uni)", "quantity": 40, "unit": "g"},
            {"name": "Nori (Roasted Seaweed Sheets)", "quantity": 0.25, "unit": "sheet"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 10, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 3, "unit": "g"},
        ]
    },

    # Nigiri (2-piece)
    {
        "menu_item": "Salmon (Sake) Nigiri",
        "serving_size": "2 pieces",
        "selling_price": 12,
        "ingredients": [
            {"name": "Raw Salmon (Sashimi-grade)", "quantity": 30, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 40, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 2, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Tuna (Maguro) Nigiri",
        "serving_size": "2 pieces",
        "selling_price": 14,
        "ingredients": [
            {"name": "Raw Tuna (Sashimi-grade)", "quantity": 30, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 40, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 2, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Yellowtail (Hamachi) Nigiri",
        "serving_size": "2 pieces",
        "selling_price": 16,
        "ingredients": [
            {"name": "Raw Yellowtail (Hamachi)", "quantity": 30, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 40, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 2, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Sea Urchin (Uni) Gunkan Nigiri",
        "serving_size": "2 pieces",
        "selling_price": 35,
        "ingredients": [
            {"name": "Fresh Sea Urchin (Uni)", "quantity": 25, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 40, "unit": "g"},
            {"name": "Nori (Roasted Seaweed Sheets)", "quantity": 0.25, "unit": "sheet"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 10, "unit": "ml"},
        ]
    },

    # Maki Rolls (6-8 piece)
    {
        "menu_item": "Spicy Tuna Roll",
        "serving_size": "6-8 pieces",
        "selling_price": 24,
        "ingredients": [
            {"name": "Raw Tuna (Sashimi-grade)", "quantity": 60, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 120, "unit": "g"},
            {"name": "Nori (Roasted Seaweed Sheets)", "quantity": 1, "unit": "sheet"},
            {"name": "Sriracha / Chili Oil", "quantity": 10, "unit": "g"},
            {"name": "Kewpie Mayonnaise", "quantity": 10, "unit": "g"},
            {"name": "Scallions / Spring Onions", "quantity": 5, "unit": "g"},
            {"name": "White Sesame Seeds", "quantity": 2, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "California Roll",
        "serving_size": "6-8 pieces",
        "selling_price": 20,
        "ingredients": [
            {"name": "Imitation Crab Stick (Surimi)", "quantity": 50, "unit": "g"},
            {"name": "Avocado", "quantity": 30, "unit": "g"},
            {"name": "Cucumber", "quantity": 20, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 120, "unit": "g"},
            {"name": "Nori (Roasted Seaweed Sheets)", "quantity": 1, "unit": "sheet"},
            {"name": "Kewpie Mayonnaise", "quantity": 15, "unit": "g"},
            {"name": "White Sesame Seeds", "quantity": 3, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },
    {
        "menu_item": "Spider Roll",
        "serving_size": "6-8 pieces",
        "selling_price": 28,
        "ingredients": [
            {"name": "Soft Shell Crab (Flash-frozen)", "quantity": 80, "unit": "g"},
            {"name": "All-Purpose / Tempura Flour", "quantity": 15, "unit": "g"},
            {"name": "Frying Oil (Canola/Vegetable)", "quantity": 30, "unit": "ml"},
            {"name": "Cucumber", "quantity": 20, "unit": "g"},
            {"name": "Prepared Sushi Rice", "quantity": 120, "unit": "g"},
            {"name": "Nori (Roasted Seaweed Sheets)", "quantity": 1, "unit": "sheet"},
            {"name": "Kewpie Mayonnaise", "quantity": 15, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Wasabi Paste", "quantity": 5, "unit": "g"},
            {"name": "Pickled Ginger (Gari)", "quantity": 10, "unit": "g"},
        ]
    },

    # Hot Mains
    {
        "menu_item": "Tonkatsu (Pork Cutlet)",
        "serving_size": "1 plate",
        "selling_price": 26,
        "ingredients": [
            {"name": "Raw Pork Loin/Fillet", "quantity": 150, "unit": "g"},
            {"name": "Fresh Eggs", "quantity": 25, "unit": "g"},
            {"name": "All-Purpose / Tempura Flour", "quantity": 15, "unit": "g"},
            {"name": "Panko Breadcrumbs", "quantity": 40, "unit": "g"},
            {"name": "Frying Oil (Canola/Vegetable)", "quantity": 30, "unit": "ml"},
            {"name": "Tonkatsu Sauce", "quantity": 30, "unit": "ml"},
        ]
    },
    {
        "menu_item": "Chicken Katsu",
        "serving_size": "1 plate",
        "selling_price": 22,
        "ingredients": [
            {"name": "Raw Chicken Breast/Thigh", "quantity": 150, "unit": "g"},
            {"name": "Fresh Eggs", "quantity": 25, "unit": "g"},
            {"name": "All-Purpose / Tempura Flour", "quantity": 15, "unit": "g"},
            {"name": "Panko Breadcrumbs", "quantity": 40, "unit": "g"},
            {"name": "Frying Oil (Canola/Vegetable)", "quantity": 30, "unit": "ml"},
            {"name": "Tonkatsu Sauce", "quantity": 30, "unit": "ml"},
        ]
    },
    {
        "menu_item": "Katsu Curry Rice",
        "serving_size": "1 plate",
        "selling_price": 28,
        "ingredients": [
            {"name": "Raw Chicken Breast/Thigh", "quantity": 100, "unit": "g"},
            {"name": "Fresh Eggs", "quantity": 15, "unit": "g"},
            {"name": "All-Purpose / Tempura Flour", "quantity": 10, "unit": "g"},
            {"name": "Panko Breadcrumbs", "quantity": 25, "unit": "g"},
            {"name": "Frying Oil (Canola/Vegetable)", "quantity": 20, "unit": "ml"},
            {"name": "Japanese Curry Blocks (Roux)", "quantity": 35, "unit": "g"},
            {"name": "Potatoes", "quantity": 60, "unit": "g"},
            {"name": "Carrots", "quantity": 40, "unit": "g"},
            {"name": "Yellow Onions", "quantity": 40, "unit": "g"},
            {"name": "Short-Grain Japanese Sushi Rice", "quantity": 200, "unit": "g"},
            {"name": "Filtered Water", "quantity": 150, "unit": "ml"},
        ]
    },

    # Sides & Staples
    {
        "menu_item": "Udon",
        "serving_size": "1 bowl",
        "selling_price": 20,
        "ingredients": [
            {"name": "Frozen Udon Noodles", "quantity": 200, "unit": "g"},
            {"name": "Prepared Dashi Broth", "quantity": 350, "unit": "ml"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 15, "unit": "ml"},
            {"name": "Mirin", "quantity": 10, "unit": "ml"},
            {"name": "Kamaboko (Fish Cake)", "quantity": 20, "unit": "g"},
            {"name": "Scallions / Spring Onions", "quantity": 10, "unit": "g"},
            {"name": "Wakame (Dried Seaweed)", "quantity": 5, "unit": "g"},
        ]
    },
    {
        "menu_item": "Edamame",
        "serving_size": "1 side",
        "selling_price": 8,
        "ingredients": [
            {"name": "Frozen Edamame", "quantity": 150, "unit": "g"},
            {"name": "Sea Salt / Kosher Salt", "quantity": 3, "unit": "g"},
            {"name": "Filtered Water", "quantity": 500, "unit": "ml"},
        ]
    },
    {
        "menu_item": "Miso Soup",
        "serving_size": "1 bowl",
        "selling_price": 6,
        "ingredients": [
            {"name": "Prepared Dashi Broth", "quantity": 200, "unit": "ml"},
            {"name": "Miso Paste", "quantity": 15, "unit": "g"},
            {"name": "Silken Tofu", "quantity": 30, "unit": "g"},
            {"name": "Wakame (Dried Seaweed)", "quantity": 5, "unit": "g"},
            {"name": "Scallions / Spring Onions", "quantity": 5, "unit": "g"},
        ]
    },
    {
        "menu_item": "Chawanmushi (Egg Custard)",
        "serving_size": "1 cup",
        "selling_price": 10,
        "ingredients": [
            {"name": "Fresh Eggs", "quantity": 50, "unit": "g"},
            {"name": "Prepared Dashi Broth", "quantity": 120, "unit": "ml"},
            {"name": "Raw Shrimp", "quantity": 15, "unit": "g"},
            {"name": "Raw Chicken Breast/Thigh", "quantity": 15, "unit": "g"},
            {"name": "Kamaboko (Fish Cake)", "quantity": 10, "unit": "g"},
            {"name": "Shiitake Mushrooms", "quantity": 10, "unit": "g"},
            {"name": "Soy Sauce (Shoyu)", "quantity": 5, "unit": "ml"},
            {"name": "Mirin", "quantity": 5, "unit": "ml"},
        ]
    },

    # Beverages
    {
        "menu_item": "Green Tea",
        "serving_size": "1 cup",
        "selling_price": 4,
        "ingredients": [
            {"name": "Green Tea Leaves / Sencha", "quantity": 4, "unit": "g"},
            {"name": "Filtered Water", "quantity": 250, "unit": "ml"},
        ]
    },
    {
        "menu_item": "Lemon Tea",
        "serving_size": "1 cup",
        "selling_price": 6,
        "ingredients": [
            {"name": "Black Tea Leaves/Bags", "quantity": 5, "unit": "g"},
            {"name": "Fresh Lemons", "quantity": 15, "unit": "g"},
            {"name": "White Sugar", "quantity": 10, "unit": "g"},
            {"name": "Filtered Water", "quantity": 250, "unit": "ml"},
        ]
    },
    {
        "menu_item": "Plain Water",
        "serving_size": "1 cup",
        "selling_price": 1,
        "ingredients": [
            {"name": "Filtered Water", "quantity": 250, "unit": "ml"},
        ]
    },
]


def main():
    # Step 1: Load expiry reference data
    print("=" * 60)
    print("STEP 1: Loading Expiry Reference Data")
    print("=" * 60)
    added_count = 0
    for ref in expiry_refs:
        record = {
            "id": katsu_db.get_next_id("exp_ref"),
            "ingredient_category": ref.get("ingredient_category", ""),
            "ingredient_name": ref.get("ingredient_name", ""),
            "shelf_life_days": int(ref.get("shelf_life_days", 0)),
            "storage_conditions": ref.get("storage_conditions", ""),
            "shelf_life_source": "Menu Katsu Zushi PDF",
            "notes": ref.get("notes", ""),
            "created": datetime.now().isoformat()
        }
        if katsu_db.add_record("expiry_ref.json", record, "expiry_reference"):
            added_count += 1

    all_refs = katsu_db.load_data("expiry_ref.json").get("expiry_reference", [])
    print(f"  Records added: {added_count}")
    print(f"  Total reference records: {len(all_refs)}")

    categories = {}
    for r in all_refs:
        cat = r.get("ingredient_category", "Unknown")
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(r.get("ingredient_name", ""))

    print("\n  Reference by Category:")
    for cat, items in categories.items():
        print(f"    {cat} ({len(items)} items)")

    # Step 2: Register recipes
    print("\n" + "=" * 60)
    print("STEP 2: Registering Menu Recipes")
    print("=" * 60)
    added_recipes = 0
    for recipe_data in recipes:
        menu_item = recipe_data["menu_item"].strip()

        existing = katsu_db.find_recipe(menu_item)
        if existing:
            print(f"  ~ {menu_item} - ALREADY EXISTS, skipping")
            continue

        recipe = {
            "id": katsu_db.get_next_id("rec"),
            "menu_item": menu_item,
            "ingredients": [],
            "serving_size": recipe_data.get("serving_size", ""),
            "selling_price": recipe_data.get("selling_price", 0),
            "recipe_version": "1.0",
            "last_updated": datetime.now().strftime("%Y-%m-%d"),
            "created": datetime.now().isoformat()
        }

        for ing in recipe_data.get("ingredients", []):
            recipe["ingredients"].append({
                "name": ing["name"].strip(),
                "quantity": float(ing["quantity"]),
                "unit": ing["unit"].strip()
            })

        if katsu_db.add_record("recipes.json", recipe, "recipes"):
            # Also register/update ingredients
            for ing in recipe["ingredients"]:
                from inventory_manager import ensure_ingredient
                ensure_ingredient(ing["name"], ing["unit"])
            print(f"  + [{recipe['id']}] {menu_item} - {len(recipe['ingredients'])} ingredients - RM{recipe['selling_price']}")
            added_recipes += 1

    total_recipes = len(katsu_db.load_data("recipes.json").get("recipes", []))
    print(f"\n  Recipes added: {added_recipes}")
    print(f"  Total recipes in system: {total_recipes}")

    # Step 3: Update existing batches with estimated expiry dates
    print("\n" + "=" * 60)
    print("STEP 3: Updating Batch Expiry Dates")
    print("=" * 60)

    batch_data = katsu_db.load_data("batches.json")
    batches = batch_data.get("batches", [])
    updated_count = 0

    for batch in batches:
        if batch.get("actual_expiry_date"):
            # Already has confirmed expiry, skip
            continue

        ing_name = batch.get("ingredient_name", "")
        receipt_date_str = batch.get("receipt_date", batch.get("purchase_date", ""))

        # Find matching expiry reference
        refs = katsu_db.get_expiry_reference(ingredient_name=ing_name)

        if refs:
            ref = refs[0]
            shelf_life = ref.get("shelf_life_days", 0)
            storage = ref.get("storage_conditions", "")

            if shelf_life and shelf_life > 0:
                try:
                    base_date = datetime.strptime(str(receipt_date_str)[:10], "%Y-%m-%d")
                    estimated_expiry = (base_date + timedelta(days=shelf_life)).strftime("%Y-%m-%d")
                    batch["estimated_expiry_date"] = estimated_expiry
                    batch["shelf_life_days"] = shelf_life
                    batch["storage_conditions"] = storage
                    batch["expiry_type"] = "estimated"
                    updated_count += 1
                    print(f"  {ing_name}: {estimated_expiry} (estimated, {shelf_life} days from {receipt_date_str})")
                except (ValueError, TypeError) as e:
                    print(f"  {ing_name}: Could not calculate - {e}")
            else:
                batch["storage_conditions"] = storage
                batch["expiry_type"] = "unknown"
                print(f"  {ing_name}: No shelf-life duration (perishable/prepared)")
        else:
            print(f"  {ing_name}: NO MATCHING EXPIRY REFERENCE FOUND")

    katsu_db.save_data("batches.json", batch_data)
    print(f"\n  Batches updated: {updated_count}")

    # Step 4: Record file hash for duplicate prevention
    print("\n" + "=" * 60)
    print("STEP 4: Recording File Hash")
    print("=" * 60)

    pdf_path = r'C:\Users\user\Downloads\Menu Katsu Zushi.pdf'
    with open(pdf_path, 'rb') as f:
        file_hash = hashlib.md5(f.read()).hexdigest()

    pf_data = katsu_db.load_data("processed_files.json")
    if "processed_files" not in pf_data:
        pf_data["processed_files"] = []

    existing = [f for f in pf_data["processed_files"] if f.get("file_hash") == file_hash]
    if not existing:
        entry = {
            "file_name": "Menu Katsu Zushi.pdf",
            "file_path": pdf_path,
            "file_hash": file_hash,
            "po_reference": None,
            "processed_date": datetime.now().strftime("%Y-%m-%d"),
            "type": "menu_and_expiry_reference"
        }
        pf_data["processed_files"].append(entry)
        katsu_db.save_data("processed_files.json", pf_data)
        print("  File hash recorded for duplicate prevention.")
    else:
        print("  File already processed (duplicate detected).")

    print("\n" + "=" * 60)
    print("ALL STEPS COMPLETED SUCCESSFULLY")
    print("=" * 60)


if __name__ == "__main__":
    main()
