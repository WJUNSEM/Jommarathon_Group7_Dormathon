#!/usr/bin/env python3
"""
Katsu Zushi - Inventory Manager
Handles recipe management, stock top-up from POs, daily sales deduction, unit conversion, and display.

Usage:
    python inventory_manager.py add-recipes '<json_array>'       # Add menu recipes
    python inventory_manager.py process-po '<json_array>' '<po_ref>' [confirmed]  # Process PO
    python inventory_manager.py process-sales '<json_array>' '<source>'  # Process daily sales
    python inventory_manager.py show                              # Show inventory table
    python inventory_manager.py history [ingredient_name]        # Show transaction history
    python inventory_manager.py check-ingredient <name>           # Check specific ingredient stock
    python inventory_manager.py correct-stock '<json>'            # Correct stock quantity
"""

import json
import sys
import os
from datetime import datetime

# Import database module
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import katsu_db


# ============================================================================
# UNIT CONVERSION
# ============================================================================

# Base unit conversions (weight and volume only)
# Packs/boxes/bottles are handled specially using their contents
BASE_CONVERSIONS = {
    "kg": ("g", 1000),
    "g": ("g", 1),
    "gram": ("g", 1),
    "grams": ("g", 1),
    "l": ("ml", 1000),
    "ml": ("ml", 1),
    "litre": ("ml", 1000),
    "liter": ("ml", 1000),
    "piece": ("piece", 1),
    "pc": ("piece", 1),
    "pcs": ("piece", 1),
    "pieces": ("piece", 1),
}

# Pack-type units that need content info to convert
PACK_UNITS = {"pack", "box", "bottle", "qty", "carton", "case"}


def normalize_unit(unit):
    """Normalize a unit string to lowercase standard form."""
    if not unit:
        return "unknown"
    return unit.lower().strip()


def convert_to_standard(quantity, unit, pack_size_qty=None, pack_size_content=None, pack_size_measure=None):
    """
    Convert a quantity to its standard measurement unit.
    
    For weight: everything to grams
    For volume: everything to milliliters
    For pieces: stays as pieces
    
    For packs/boxes/bottles: convert to contents if pack_size is known.
    This is CRITICAL - never treat 1 pack as 1g unless explicitly stated.
    """
    unit = normalize_unit(unit)
    quantity = float(quantity)
    
    # Direct weight/volume/piece units
    if unit in BASE_CONVERSIONS:
        std_unit, factor = BASE_CONVERSIONS[unit]
        return quantity * factor, std_unit
    
    # Pack-type units: convert to content's measurement unit
    if unit in PACK_UNITS:
        if pack_size_content and pack_size_measure:
            std_measure = normalize_unit(pack_size_measure)
            if std_measure in BASE_CONVERSIONS:
                target_unit, factor = BASE_CONVERSIONS[std_measure]
                total = quantity * float(pack_size_content) * factor
                return total, target_unit
            # If the pack's content measure isn't known, return as-is with that unit
            return quantity * float(pack_size_content), std_measure
        # No content info - return as pack unit (can't convert)
        return quantity, unit
    
    # Unknown unit - return as-is
    return quantity, unit


def format_stock_display(amount, pack_content, pack_measure):
    """
    Format stock as 'N Qty + leftover unit'.
    
    Example: 3500g with 1000g packs -> '3 Qty + 500 g'
    """
    if pack_content and pack_content > 0:
        full_packs = int(amount // pack_content)
        leftover = amount - (full_packs * pack_content)
        if leftover > 0:
            return f"{full_packs} Qty + {format_amount(leftover)} {pack_measure}"
        return f"{full_packs} Qty"
    return f"{format_amount(amount)} {pack_measure}"


def format_amount(amount):
    """Format a number nicely (remove trailing zeros)."""
    if amount == int(amount):
        return str(int(amount))
    return f"{amount:.2f}".rstrip('0').rstrip('.')


# ============================================================================
# RECIPE MANAGEMENT
# ============================================================================

def add_recipes(recipes_json):
    """
    Add menu recipes from JSON array.
    
    Expected format:
    [
        {
            "menu_item": "Chicken Katsu Don",
            "ingredients": [
                {"name": "Chicken Breast", "quantity": 120, "unit": "g"},
                {"name": "Panko Breadcrumbs", "quantity": 50, "unit": "g"}
            ],
            "serving_size": "1 bowl",
            "selling_price": 15.90
        }
    ]
    """
    recipes = json.loads(recipes_json) if isinstance(recipes_json, str) else recipes_json
    
    if not isinstance(recipes, list):
        print("ERROR: Expected a JSON array of recipes")
        return False
    
    results = []
    added_count = 0
    skipped_count = 0
    
    for recipe_data in recipes:
        menu_item = recipe_data.get("menu_item", "").strip()
        if not menu_item:
            results.append({"status": "skipped", "reason": "No menu item name"})
            skipped_count += 1
            continue
        
        # Check if recipe already exists
        existing = katsu_db.find_recipe(menu_item)
        if existing:
            results.append({
                "status": "exists",
                "menu_item": menu_item,
                "existing_id": existing["id"],
                "message": f"Recipe for '{menu_item}' already exists. Use correct-stock to update."
            })
            skipped_count += 1
            continue
        
        # Build recipe record
        recipe = {
            "id": katsu_db.get_next_id("rec"),
            "menu_item": menu_item,
            "ingredients": [],
            "serving_size": recipe_data.get("serving_size", ""),
            "selling_price": recipe_data.get("selling_price", 0),
            "recipe_version": recipe_data.get("recipe_version", "1.0"),
            "last_updated": recipe_data.get("last_updated", datetime.now().strftime("%Y-%m-%d")),
            "created": datetime.now().isoformat()
        }
        
        for ing in recipe_data.get("ingredients", []):
            recipe["ingredients"].append({
                "name": ing.get("name", "").strip(),
                "quantity": float(ing.get("quantity", 0)),
                "unit": ing.get("unit", "").strip()
            })
        
        # Save recipe
        if katsu_db.add_record("recipes.json", recipe, "recipes"):
            # Also register/update ingredients
            for ing in recipe["ingredients"]:
                ensure_ingredient(ing["name"], ing["unit"])
            
            results.append({
                "status": "added",
                "id": recipe["id"],
                "menu_item": menu_item,
                "ingredient_count": len(recipe["ingredients"])
            })
            added_count += 1
        else:
            results.append({
                "status": "failed",
                "menu_item": menu_item,
                "error": "Failed to save recipe"
            })
    
    print("=== Recipe Registration Results ===")
    print(f"Added: {added_count}, Skipped: {skipped_count}")
    print()
    for r in results:
        if r["status"] == "added":
            print(f"  + [{r['id']}] {r['menu_item']} - {r['ingredient_count']} ingredients")
        elif r["status"] == "exists":
            print(f"  ~ {r['menu_item']} - ALREADY EXISTS ({r['existing_id']})")
        elif r["status"] == "skipped":
            print(f"  - SKIPPED: {r.get('reason', 'Unknown')}")
        elif r["status"] == "failed":
            print(f"  ! FAILED: {r.get('menu_item', 'Unknown')} - {r.get('error', '')}")
    
    print(f"\nTotal recipes in system: {len(katsu_db.load_data('recipes.json').get('recipes', []))}")
    return True


def ensure_ingredient(name, unit):
    """Create ingredient record if it doesn't exist."""
    existing = katsu_db.find_ingredient(name)
    if existing:
        return existing
    
    std_unit = normalize_unit(unit)
    ingredient = {
        "id": katsu_db.get_next_id("ing"),
        "name": name,
        "alternative_names": [],
        "standard_unit": std_unit,
        "pack_size_qty": 1,
        "pack_size_unit": 1,
        "pack_size_measure": std_unit,
        "current_stock_qty": 0,
        "current_stock_amount": 0,
        "current_stock_display": f"0 {std_unit}",
        "pending_stock_qty": 0,
        "pending_stock_amount": 0,
        "weighted_avg_cost_per_unit": 0,
        "last_purchase_price": 0,
        "last_purchase_supplier": "",
        "last_updated": datetime.now().isoformat(),
        "created": datetime.now().isoformat()
    }
    
    if katsu_db.add_record("ingredients.json", ingredient, "ingredients"):
        return ingredient
    return None


# ============================================================================
# PURCHASE ORDER PROCESSING
# ============================================================================

def process_po(po_items_json, po_reference, confirmed="true"):
    """
    Process a Purchase Order: add stock, create batches, record supplier prices.
    
    Expected format for po_items:
    [
        {
            "ingredient_name": "Panko Breadcrumbs",
            "supplier": "Supplier A",
            "purchase_date": "2025-01-01",
            "quantity": 3,
            "purchase_unit": "pack",
            "pack_size_content": 1000,
            "pack_size_measure": "g",
            "price_per_pack": 12.00,
            "total_cost": 36.00,
            "actual_expiry_date": null,
            "storage_conditions": "Room Temperature"
        }
    ]
    """
    po_items = json.loads(po_items_json) if isinstance(po_items_json, str) else po_items_json
    is_confirmed = confirmed.lower() in ("true", "yes", "1", "confirmed")
    
    if not isinstance(po_items, list):
        print("ERROR: Expected a JSON array of PO items")
        return False
    
    results = []
    
    for item in po_items:
        ing_name = item.get("ingredient_name", "").strip()
        supplier = item.get("supplier", "").strip()
        purchase_date = item.get("purchase_date", datetime.now().strftime("%Y-%m-%d"))
        receipt_date = item.get("receipt_date", purchase_date)
        
        # Get quantity and unit info
        qty = float(item.get("quantity", 0))
        purchase_unit = item.get("purchase_unit", "pack")
        pack_content = float(item.get("pack_size_content", 0)) if item.get("pack_size_content") else None
        pack_measure = item.get("pack_size_measure", "")
        price_per_pack = float(item.get("price_per_pack", 0))
        total_cost = float(item.get("total_cost", 0))
        actual_expiry = item.get("actual_expiry_date")
        storage = item.get("storage_conditions", "")
        
        if not ing_name:
            results.append({"status": "skipped", "reason": "No ingredient name"})
            continue
        
        # Convert to standard unit
        std_amount, std_unit = convert_to_standard(
            qty, purchase_unit, pack_size_qty=qty, 
            pack_size_content=pack_content, pack_size_measure=pack_measure
        )
        
        # If no pack content, use the raw amount
        if pack_content is None or pack_content == 0:
            # Direct unit (e.g., 500g of chicken)
            std_amount, std_unit = convert_to_standard(qty, purchase_unit)
            pack_content_for_display = 1
            pack_measure_for_display = std_unit
        else:
            pack_content_for_display = pack_content
            pack_measure_for_display = pack_measure
        
        # Ensure ingredient exists
        ing = ensure_ingredient(ing_name, std_unit)
        
        # Calculate comparable unit price
        if std_amount > 0 and total_cost > 0:
            unit_price = total_cost / std_amount
        elif std_amount > 0 and price_per_pack > 0 and pack_content:
            unit_price = price_per_pack / pack_content
        else:
            unit_price = 0
        
        # Get previous values for inventory update
        prev_qty = ing.get("current_stock_qty", 0)
        prev_amount = ing.get("current_stock_amount", 0)
        
        # Update ingredient stock
        ing_data = katsu_db.load_data("ingredients.json")
        for i in ing_data.get("ingredients", []):
            if i["id"] == ing["id"]:
                # Update pack size if we have new info
                if pack_content:
                    i["pack_size_unit"] = pack_content
                    i["pack_size_measure"] = pack_measure
                
                # Add to stock
                if is_confirmed:
                    i["current_stock_qty"] = prev_qty + qty
                    i["current_stock_amount"] = prev_amount + std_amount
                    i["current_stock_display"] = format_stock_display(
                        i["current_stock_amount"], pack_content_for_display, pack_measure_for_display
                    )
                else:
                    i["pending_stock_qty"] = i.get("pending_stock_qty", 0) + qty
                    i["pending_stock_amount"] = i.get("pending_stock_amount", 0) + std_amount
                
                # Update cost info
                if unit_price > 0:
                    # Weighted average cost
                    if prev_amount > 0 and i.get("weighted_avg_cost_per_unit", 0) > 0:
                        prev_value = prev_amount * i["weighted_avg_cost_per_unit"]
                        new_value = std_amount * unit_price
                        total_value = prev_value + new_value
                        total_qty = prev_amount + std_amount
                        i["weighted_avg_cost_per_unit"] = total_value / total_qty if total_qty > 0 else unit_price
                    else:
                        i["weighted_avg_cost_per_unit"] = unit_price
                    i["last_purchase_price"] = price_per_pack
                    i["last_purchase_supplier"] = supplier
                
                i["last_updated"] = datetime.now().isoformat()
                break
        katsu_db.save_data("ingredients.json", ing_data)
        
        # Create batch for expiry tracking
        batch_id = katsu_db.get_next_id("bat")
        
        # Estimate expiry if not provided
        estimated_expiry = actual_expiry
        expiry_type = "confirmed" if actual_expiry else None
        shelf_life_days = None
        
        if not actual_expiry:
            # Check expiry reference
            refs = katsu_db.get_expiry_reference(ingredient_name=ing_name)
            if not refs:
                refs = katsu_db.get_expiry_reference(category=item.get("ingredient_category", ""))
            
            if refs:
                ref = refs[0]
                shelf_life_days = ref.get("shelf_life_days")
                storage = storage or ref.get("storage_conditions", "")
                if shelf_life_days:
                    from datetime import datetime as dt, timedelta
                    try:
                        base_date = dt.strptime(receipt_date, "%Y-%m-%d")
                        estimated_expiry = (base_date + timedelta(days=shelf_life_days)).strftime("%Y-%m-%d")
                    except (ValueError, TypeError):
                        estimated_expiry = None
            expiry_type = "estimated" if estimated_expiry else None
        
        batch = {
            "id": batch_id,
            "ingredient_id": ing["id"],
            "ingredient_name": ing_name,
            "supplier": supplier,
            "po_reference": po_reference,
            "purchase_date": purchase_date,
            "receipt_date": receipt_date,
            "registration_date": datetime.now().isoformat(),
            "quantity_received_qty": qty,
            "quantity_received_amount": std_amount,
            "pack_size": f"{int(pack_content_for_display)} {pack_measure_for_display} per pack" if pack_content else f"{format_amount(std_amount)} {std_unit}",
            "unit": std_unit,
            "actual_expiry_date": actual_expiry if actual_expiry else None,
            "estimated_expiry_date": estimated_expiry if not actual_expiry else None,
            "shelf_life_days": shelf_life_days,
            "storage_conditions": storage,
            "remaining_qty": qty,
            "remaining_amount": std_amount,
            "expiry_status": "OK",
            "expiry_type": expiry_type or "unknown",
            "active": is_confirmed,
            "created": datetime.now().isoformat()
        }
        katsu_db.add_record("batches.json", batch, "batches")
        
        # Record supplier price
        ensure_supplier(supplier)
        price_record = {
            "id": katsu_db.get_next_id("pr"),
            "ingredient_name": ing_name,
            "supplier": supplier,
            "purchase_date": purchase_date,
            "po_reference": po_reference,
            "purchase_qty": qty,
            "purchase_unit": purchase_unit,
            "pack_size": f"{int(pack_content)} {pack_measure} per pack" if pack_content else "N/A",
            "price_per_pack": price_per_pack,
            "total_purchase_cost": total_cost,
            "comparable_unit_price": unit_price,
            "comparable_unit": std_unit,
            "discounts": float(item.get("discounts", 0)),
            "delivery_charges": float(item.get("delivery_charges", 0)),
            "effective_price_per_pack": price_per_pack - float(item.get("discounts", 0)) + float(item.get("delivery_charges", 0)),
            "effective_unit_price": unit_price,  # Simplified; should recalculate
            "price_type": "listed",
            "created": datetime.now().isoformat()
        }
        katsu_db.add_record_to_sublist("suppliers.json", "price_records", price_record)
        
        # Record transaction
        katsu_db.record_transaction(
            ingredient_name=ing_name,
            quantity=std_amount,
            unit=std_unit,
            txn_type="addition" if is_confirmed else "pending",
            source=po_reference,
            reason=f"Stock received from PO ({supplier})" if is_confirmed else f"Pending stock from PO ({supplier})",
            batch_id=batch_id,
            value=total_cost
        )
        
        # Update inventory record
        katsu_db.update_inventory_record(
            ing_name, prev_qty, prev_amount,
            qty if is_confirmed else 0, std_amount if is_confirmed else 0,
            0, 0
        )
        
        results.append({
            "status": "added",
            "ingredient": ing_name,
            "supplier": supplier,
            "quantity": qty,
            "std_amount": std_amount,
            "std_unit": std_unit,
            "batch_id": batch_id,
            "expiry": actual_expiry or estimated_expiry or "Unknown",
            "expiry_type": expiry_type or "unknown",
            "confirmed": is_confirmed,
            "unit_price": unit_price
        })
    
    print("=== Purchase Order Processing Results ===")
    print(f"PO Reference: {po_reference}")
    print(f"Status: {'CONFIRMED - Stock Added' if is_confirmed else 'PENDING - Awaiting Confirmation'}")
    print()
    
    for r in results:
        status_icon = "+" if r["confirmed"] else "P"
        print(f"  {status_icon} {r['ingredient']}")
        print(f"    Supplier: {r['supplier']}")
        print(f"    Received: {r['quantity']} units ({format_amount(r['std_amount'])} {r['std_unit']})")
        print(f"    Batch: {r['batch_id']}")
        print(f"    Expiry: {r['expiry']} ({r['expiry_type']})")
        if r['unit_price'] > 0:
            print(f"    Unit Price: RM{r['unit_price']:.4f}/{r['std_unit']}")
        print()
    
    return True


def ensure_supplier(name):
    """Create supplier record if it doesn't exist."""
    if not name:
        return None
    existing = katsu_db.find_supplier(name)
    if existing:
        return existing
    
    supplier = {
        "id": katsu_db.get_next_id("sup"),
        "name": name,
        "contact": None,
        "address": None,
        "phone": None,
        "created": datetime.now().isoformat()
    }
    katsu_db.add_record_to_sublist("suppliers.json", "suppliers", supplier)
    return supplier


# ============================================================================
# DAILY SALES PROCESSING
# ============================================================================

def process_sales(sales_json, source_document):
    """
    Process daily sales: deduct ingredients from inventory using FEFO.
    
    Expected format:
    [
        {
            "menu_item": "Chicken Katsu Don",
            "quantity_sold": 20,
            "selling_price": 15.90,
            "gross_sales": 318.00,
            "discounts": 0,
            "refunds": 0,
            "cancelled_orders": 0,
            "net_sales_revenue": 318.00,
            "sales_date": "2025-01-02"
        }
    ]
    """
    sales = json.loads(sales_json) if isinstance(sales_json, str) else sales_json
    
    if not isinstance(sales, list):
        print("ERROR: Expected a JSON array of sales records")
        return False
    
    results = []
    deductions = {}  # ingredient_name -> total_amount_to_deduct
    missing_recipes = []
    sales_added = 0
    
    for sale in sales:
        menu_item = sale.get("menu_item", "").strip()
        qty_sold = int(sale.get("quantity_sold", 0))
        selling_price = float(sale.get("selling_price", 0))
        
        # Calculate financial fields
        gross = qty_sold * selling_price
        discounts = float(sale.get("discounts", 0))
        refunds = float(sale.get("refunds", 0))
        cancelled = int(sale.get("cancelled_orders", 0))
        
        # If net_sales_revenue provided, use it; otherwise calculate
        if "net_sales_revenue" in sale:
            net_revenue = float(sale["net_sales_revenue"])
        else:
            net_revenue = gross - discounts - refunds
        
        sales_date = sale.get("sales_date", datetime.now().strftime("%Y-%m-%d"))
        
        # Find recipe
        recipe = katsu_db.find_recipe(menu_item)
        if not recipe:
            missing_recipes.append(menu_item)
            results.append({
                "status": "missing_recipe",
                "menu_item": menu_item,
                "quantity": qty_sold
            })
            continue
        
        # Calculate ingredient usage
        for ing in recipe.get("ingredients", []):
            ing_name = ing["name"]
            ing_qty = float(ing["quantity"])
            ing_unit = ing.get("unit", "g")
            
            # Convert to standard unit
            std_amount, std_unit = convert_to_standard(ing_qty, ing_unit)
            
            total_usage = qty_sold * std_amount
            
            if ing_name in deductions:
                deductions[ing_name]["total_amount"] += total_usage
                deductions[ing_name]["total_std_unit"] = std_unit
            else:
                deductions[ing_name] = {
                    "total_amount": total_usage,
                    "total_std_unit": std_unit
                }
        
        # Record sale
        sale_record = {
            "id": katsu_db.get_next_id("sale"),
            "sales_date": sales_date,
            "menu_item": menu_item,
            "quantity_sold": qty_sold,
            "selling_price": selling_price,
            "gross_sales": gross,
            "discounts": discounts,
            "refunds": refunds,
            "cancelled_orders": cancelled,
            "net_sales_revenue": net_revenue,
            "source_document": source_document,
            "processed": True,
            "created": datetime.now().isoformat()
        }
        katsu_db.add_record("sales.json", sale_record, "sales")
        sales_added += 1
        
        results.append({
            "status": "processed",
            "menu_item": menu_item,
            "quantity": qty_sold,
            "gross_sales": gross,
            "net_revenue": net_revenue
        })
    
    # Apply FEFO deductions
    print("=== Daily Sales Processing ===")
    print(f"Source: {source_document}")
    print(f"Sales records: {sales_added} added")
    
    if missing_recipes:
        print(f"\n⚠️  MISSING RECIPES (cannot deduct ingredients):")
        for item in missing_recipes:
            print(f"   - {item}")
        print("   Please provide the missing recipes before processing these items.")
    
    print(f"\n--- Ingredient Deductions (FEFO) ---")
    
    shortages = []
    
    for ing_name, deduction_info in deductions.items():
        total_to_deduct = deduction_info["total_amount"]
        std_unit = deduction_info["total_std_unit"]
        
        print(f"\n  {ing_name}: Need to deduct {format_amount(total_to_deduct)} {std_unit}")
        
        # Get batches sorted by expiry (FEFO)
        batches = katsu_db.get_all_batches(ingredient_name=ing_name, active_only=True)
        
        if not batches:
            print(f"    ⚠️  NO AVAILABLE STOCK - Shortage of {format_amount(total_to_deduct)} {std_unit}")
            shortages.append({
                "ingredient": ing_name,
                "needed": total_to_deduct,
                "available": 0,
                "shortage": total_to_deduct,
                "unit": std_unit
            })
            katsu_db.record_transaction(
                ing_name, total_to_deduct, std_unit,
                "deduction", source_document,
                f"Sales deduction - SHORTAGE (no stock available)",
                value=None
            )
            continue
        
        # Deduct from batches using FEFO
        remaining_to_deduct = total_to_deduct
        batch_deductions = []
        
        for batch in batches:
            if remaining_to_deduct <= 0:
                break
            
            batch_remaining = batch.get("remaining_amount", 0)
            if batch_remaining <= 0:
                continue
            
            # Check if batch is expired
            expiry = batch.get("actual_expiry_date") or batch.get("estimated_expiry_date")
            is_expired = check_if_expired(expiry)
            if is_expired:
                print(f"    [SKIP] Batch {batch['id']} - EXPIRED (expiry: {expiry})")
                continue
            
            # Deduct from this batch
            deduct_from_batch = min(remaining_to_deduct, batch_remaining)
            new_remaining = batch_remaining - deduct_from_batch
            
            batch_deductions.append({
                "batch_id": batch["id"],
                "deducted": deduct_from_batch,
                "batch_expiry": expiry or "Unknown",
                "new_remaining": new_remaining
            })
            
            print(f"    [FEFO] Batch {batch['id']}: deduct {format_amount(deduct_from_batch)} {std_unit} "
                  f"(expiry: {expiry or 'Unknown'}, remaining: {format_amount(new_remaining)})")
            
            # Update batch
            batch_data = katsu_db.load_data("batches.json")
            for b in batch_data.get("batches", []):
                if b["id"] == batch["id"]:
                    b["remaining_amount"] = new_remaining
                    if new_remaining <= 0:
                        b["active"] = False
                    break
            katsu_db.save_data("batches.json", batch_data)
            
            remaining_to_deduct -= deduct_from_batch
        
        # Check for shortage
        if remaining_to_deduct > 0:
            print(f"    ⚠️  SHORTAGE: {format_amount(remaining_to_deduct)} {std_unit} not available")
            shortages.append({
                "ingredient": ing_name,
                "needed": total_to_deduct,
                "available": total_to_deduct - remaining_to_deduct,
                "shortage": remaining_to_deduct,
                "unit": std_unit
            })
        
        # Update ingredient stock
        ing_data = katsu_db.load_data("ingredients.json")
        for i in ing_data.get("ingredients", []):
            if i["name"].lower() == ing_name.lower():
                prev_amount = i.get("current_stock_amount", 0)
                i["current_stock_amount"] = max(0, prev_amount - total_to_deduct + remaining_to_deduct)
                # Actually: deduct what was actually deducted
                actual_deducted = total_to_deduct - remaining_to_deduct
                i["current_stock_amount"] = prev_amount - actual_deducted
                
                # Update qty display
                pack_content = i.get("pack_size_unit", 1)
                pack_measure = i.get("pack_size_measure", std_unit)
                i["current_stock_qty"] = int(i["current_stock_amount"] / pack_content) if pack_content > 0 else 0
                i["current_stock_display"] = format_stock_display(
                    i["current_stock_amount"], pack_content, pack_measure
                )
                i["last_updated"] = datetime.now().isoformat()
                break
        katsu_db.save_data("ingredients.json", ing_data)
        
        # Record transaction
        actual_deducted = total_to_deduct - remaining_to_deduct
        katsu_db.record_transaction(
            ing_name, actual_deducted, std_unit,
            "deduction", source_document,
            f"Sales deduction - {format_amount(total_to_deduct)} {std_unit} needed, "
            f"{format_amount(actual_deducted)} {std_unit} deducted (FEFO)",
            allocation_method="FEFO",
            allocation_estimated=True
        )
    
    # Update inventory records
    for ing_name in deductions:
        ing = katsu_db.find_ingredient(ing_name)
        if ing:
            katsu_db.update_inventory_record(
                ing_name,
                ing.get("current_stock_qty", 0),  # This is the new prev after deduction
                ing.get("current_stock_amount", 0),
                0, 0,  # No additions
                0, 0   # Simplified
            )
    
    # Summary
    print(f"\n=== Summary ===")
    print(f"Sales processed: {sales_added}")
    print(f"Ingredients deducted: {len(deductions)}")
    if missing_recipes:
        print(f"Missing recipes: {len(missing_recipes)}")
    if shortages:
        print(f"\n⚠️  SHORTAGES DETECTED:")
        for s in shortages:
            print(f"   {s['ingredient']}: need {format_amount(s['needed'])} {s['unit']}, "
                  f"available {format_amount(s['available'])} {s['unit']}, "
                  f"SHORT by {format_amount(s['shortage'])} {s['unit']}")
    
    return True


def check_if_expired(expiry_date_str):
    """Check if a date string is in the past."""
    if not expiry_date_str:
        return False
    try:
        from datetime import datetime as dt
        expiry = dt.strptime(expiry_date_str[:10], "%Y-%m-%d")
        return dt.now() > expiry
    except (ValueError, TypeError):
        return False


# ============================================================================
# DISPLAY FUNCTIONS
# ============================================================================

def show_inventory():
    """Display the current inventory as a table."""
    ing_data = katsu_db.load_data("ingredients.json")
    ingredients = ing_data.get("ingredients", [])
    
    if not ingredients:
        print("=== Current Inventory ===")
        print("No ingredients in inventory. Upload a Purchase Order to add stock.")
        return
    
    print("=== Current Inventory ===")
    print()
    
    # Table header
    print(f"{'Ingredient':<25} | {'Current Stock':<25} | {'Std Unit':<8} | {'Cost/Unit':<12} | {'Status'}")
    print("-" * 95)
    
    for ing in ingredients:
        name = ing.get("name", "")
        display = ing.get("current_stock_display", "0")
        unit = ing.get("standard_unit", "")
        cost = ing.get("weighted_avg_cost_per_unit", 0)
        amount = ing.get("current_stock_amount", 0)
        
        # Determine status
        if amount < 0:
            status = "⚠️ SHORTAGE"
        elif amount == 0:
            status = "Out of Stock"
        elif amount < (ing.get("pack_size_unit", 1) * 1):  # Less than 1 pack
            status = "Low Stock"
        else:
            status = "OK"
        
        cost_str = f"RM{cost:.4f}" if cost > 0 else "N/A"
        print(f"{name:<25} | {display:<25} | {unit:<8} | {cost_str:<12} | {status}")
    
    # Also show inventory table with movement columns
    inv_data = katsu_db.load_data("inventory.json")
    inventory_records = inv_data.get("inventory", [])
    
    if inventory_records:
        print()
        print("=== Inventory Movement Table ===")
        print()
        print(f"{'Ingredient':<20} | {'Prev Stock':<15} | {'Added':<10} | {'Used':<10} | {'Current Stock':<20} | {'Status'}")
        print("-" * 100)
        
        for inv in inventory_records:
            name = inv.get("ingredient_name", "")
            prev = f"{inv.get('previous_stock_qty', 0)} Qty ({format_amount(inv.get('previous_stock_amount', 0))})"
            added = f"{inv.get('stock_added_qty', 0)} Qty"
            used = f"{inv.get('stock_used_qty', 0)} Qty"
            current = f"{inv.get('current_stock_qty', 0)} Qty ({format_amount(inv.get('current_stock_amount', 0))})"
            
            amount = inv.get("current_stock_amount", 0)
            if amount < 0:
                status = "⚠️ SHORTAGE"
            elif amount == 0:
                status = "Out of Stock"
            else:
                status = "OK"
            
            print(f"{name:<20} | {prev:<15} | {added:<10} | {used:<10} | {current:<20} | {status}")
    
    print()
    pending = [i for i in ingredients if i.get("pending_stock_qty", 0) > 0]
    if pending:
        print("Pending Stock (awaiting confirmation):")
        for p in pending:
            print(f"  {p['name']}: {p['pending_stock_qty']} Qty ({format_amount(p.get('pending_stock_amount', 0))} {p.get('standard_unit', '')})")


def show_history(ingredient_name=None):
    """Display transaction history."""
    txns = katsu_db.get_all_transactions(ingredient_name=ingredient_name)
    
    print("=== Transaction History ===")
    if ingredient_name:
        print(f"Filter: {ingredient_name}")
    print()
    
    if not txns:
        print("No transactions recorded.")
        return
    
    print(f"{'Date':<12} | {'Ingredient':<20} | {'Qty':<12} | {'Unit':<6} | {'Type':<12} | {'Source':<25} | {'Reason'}")
    print("-" * 120)
    
    for t in txns:
        date_str = t.get("date", "")
        ing = t.get("ingredient_name", "")
        qty = format_amount(t.get("quantity", 0))
        unit = t.get("unit", "")
        txn_type = t.get("transaction_type", "")
        source = t.get("source_document", "")
        reason = t.get("reason", "")
        
        print(f"{date_str:<12} | {ing:<20} | {qty:<12} | {unit:<6} | {txn_type:<12} | {source:<25} | {reason}")
    
    print(f"\nTotal transactions: {len(txns)}")


def check_ingredient(name):
    """Check stock for a specific ingredient."""
    ing = katsu_db.find_ingredient(name)
    
    if not ing:
        print(f"Ingredient '{name}' not found in inventory.")
        return
    
    print(f"=== {ing['name']} Stock Status ===")
    print(f"  Standard Unit: {ing.get('standard_unit', '')}")
    print(f"  Pack Size: {ing.get('pack_size_unit', 1)} {ing.get('pack_size_measure', '')} per pack")
    print(f"  Current Stock: {ing.get('current_stock_display', '0')}")
    print(f"  Current Amount: {format_amount(ing.get('current_stock_amount', 0))} {ing.get('standard_unit', '')}")
    print(f"  Weighted Avg Cost: RM{ing.get('weighted_avg_cost_per_unit', 0):.4f}/{ing.get('standard_unit', '')}")
    print(f"  Last Purchase Price: RM{ing.get('last_purchase_price', 0):.2f}")
    print(f"  Last Supplier: {ing.get('last_purchase_supplier', 'N/A')}")
    
    pending = ing.get("pending_stock_qty", 0)
    if pending > 0:
        print(f"  Pending Stock: {pending} Qty ({format_amount(ing.get('pending_stock_amount', 0))} {ing.get('standard_unit', '')})")
    
    # Show batches
    batches = katsu_db.get_all_batches(ingredient_name=name, active_only=False)
    if batches:
        print(f"\n  Batches ({len(batches)} total):")
        for b in batches:
            status = "Active" if b.get("active", True) else "Inactive"
            expiry = b.get("actual_expiry_date") or b.get("estimated_expiry_date") or "Unknown"
            expiry_label = "Confirmed" if b.get("actual_expiry_date") else "Estimated" if b.get("estimated_expiry_date") else "Unknown"
            print(f"    [{b['id']}] {b.get('remaining_amount', 0):.1f} {b.get('unit', '')} | "
                  f"Expiry: {expiry} ({expiry_label}) | {status} | Supplier: {b.get('supplier', '')}")


def correct_stock(correction_json):
    """Correct a stock quantity with a correction transaction."""
    correction = json.loads(correction_json) if isinstance(correction_json, str) else correction_json
    
    ing_name = correction.get("ingredient_name", "").strip()
    new_amount = float(correction.get("new_amount", 0))
    reason = correction.get("reason", "Stock correction")
    unit = correction.get("unit", "")
    
    if not ing_name:
        print("ERROR: ingredient_name is required")
        return False
    
    ing = katsu_db.find_ingredient(ing_name)
    if not ing:
        print(f"ERROR: Ingredient '{ing_name}' not found")
        return False
    
    old_amount = ing.get("current_stock_amount", 0)
    difference = new_amount - old_amount
    
    # Update ingredient
    ing_data = katsu_db.load_data("ingredients.json")
    for i in ing_data.get("ingredients", []):
        if i["id"] == ing["id"]:
            i["current_stock_amount"] = new_amount
            pack_content = i.get("pack_size_unit", 1)
            pack_measure = i.get("pack_size_measure", unit or i.get("standard_unit", ""))
            i["current_stock_qty"] = int(new_amount / pack_content) if pack_content > 0 else 0
            i["current_stock_display"] = format_stock_display(new_amount, pack_content, pack_measure)
            i["last_updated"] = datetime.now().isoformat()
            break
    katsu_db.save_data("ingredients.json", ing_data)
    
    # Record correction transaction
    katsu_db.record_transaction(
        ing_name, abs(difference), unit or ing.get("standard_unit", ""),
        "correction", "manual_correction",
        f"Stock correction: {format_amount(old_amount)} -> {format_amount(new_amount)} ({reason})",
        value=None
    )
    
    print(f"=== Stock Correction ===")
    print(f"  Ingredient: {ing_name}")
    print(f"  Previous: {format_amount(old_amount)} {unit or ing.get('standard_unit', '')}")
    print(f"  Corrected: {format_amount(new_amount)} {unit or ing.get('standard_unit', '')}")
    print(f"  Difference: {format_amount(difference)} ({'+' if difference >= 0 else ''}{format_amount(difference)})")
    print(f"  Reason: {reason}")
    print(f"  Correction transaction recorded.")


# ============================================================================
# MAIN
# ============================================================================

def main():
    if len(sys.argv) < 2:
        print("Usage: python inventory_manager.py <command> [args]")
        print("Commands:")
        print("  add-recipes '<json>'               Add menu recipes")
        print("  process-po '<json>' '<po_ref>' [confirmed]  Process Purchase Order")
        print("  process-sales '<json>' '<source>'    Process daily sales (deduct inventory)")
        print("  show                                  Show current inventory")
        print("  history [ingredient_name]             Show transaction history")
        print("  check-ingredient <name>               Check specific ingredient")
        print("  correct-stock '<json>'                Correct stock quantity")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "add-recipes":
        if len(sys.argv) < 3:
            print("Usage: python inventory_manager.py add-recipes '<json_array>'")
            sys.exit(1)
        add_recipes(sys.argv[2])
    
    elif command == "process-po":
        if len(sys.argv) < 4:
            print("Usage: python inventory_manager.py process-po '<json_array>' '<po_ref>' [confirmed]")
            sys.exit(1)
        confirmed = sys.argv[4] if len(sys.argv) > 4 else "true"
        process_po(sys.argv[2], sys.argv[3], confirmed)
    
    elif command == "process-sales":
        if len(sys.argv) < 4:
            print("Usage: python inventory_manager.py process-sales '<json_array>' '<source>'")
            sys.exit(1)
        process_sales(sys.argv[2], sys.argv[3])
    
    elif command == "show":
        show_inventory()
    
    elif command == "history":
        name = sys.argv[2] if len(sys.argv) > 2 else None
        show_history(name)
    
    elif command == "check-ingredient":
        if len(sys.argv) < 3:
            print("Usage: python inventory_manager.py check-ingredient <name>")
            sys.exit(1)
        check_ingredient(sys.argv[2])
    
    elif command == "correct-stock":
        if len(sys.argv) < 3:
            print("Usage: python inventory_manager.py correct-stock '<json>'")
            sys.exit(1)
        correct_stock(sys.argv[2])
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
