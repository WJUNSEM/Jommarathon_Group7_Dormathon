#!/usr/bin/env python3
"""
Katsu Zushi - Expiry Manager
Handles batch-level expiry tracking, estimated expiry dates, FEFO stock rotation,
and 7-day / 1-day / expired warning rules.

Usage:
    python expiry_manager.py load-reference '<json_array>'   # Load expiry reference from PDF
    python expiry_manager.py check                             # Check all expiry status
    python expiry_manager.py show                              # Show expiry table
    python expiry_manager.py show-expired                      # Show only expired items
    python expiry_manager.py show-warnings                     # Show items in warning period
    python expiry_manager.py show-batch <batch_id>             # Show specific batch details
    python expiry_manager.py set-expiry <batch_id> <date>     # Set actual expiry date for batch
    python expiry_manager.py write-off <batch_id> '<reason>'  # Write off a batch
    python expiry_manager.py fefo-check <ingredient> <amount> <unit>  # Check FEFO allocation
"""

import json
import sys
import os
from datetime import datetime, date, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import katsu_db


def load_reference(ref_json):
    """
    Load expiry reference data from the Expiry Reference PDF.
    
    Expected format:
    [
        {
            "ingredient_category": "Frozen Meat",
            "ingredient_name": "Chicken Breast",
            "shelf_life_days": 180,
            "storage_conditions": "Frozen (-18C)",
            "notes": "Vacuum sealed extends 30 days"
        }
    ]
    """
    refs = json.loads(ref_json) if isinstance(ref_json, str) else ref_json
    
    if not isinstance(refs, list):
        print("ERROR: Expected a JSON array of expiry reference records")
        return False
    
    added = 0
    for ref in refs:
        record = {
            "id": katsu_db.get_next_id("exp_ref"),
            "ingredient_category": ref.get("ingredient_category", ""),
            "ingredient_name": ref.get("ingredient_name", ""),
            "shelf_life_days": int(ref.get("shelf_life_days", 0)),
            "storage_conditions": ref.get("storage_conditions", ""),
            "shelf_life_source": "Expiry Reference PDF",
            "notes": ref.get("notes", ""),
            "created": datetime.now().isoformat()
        }
        if katsu_db.add_record("expiry_ref.json", record, "expiry_reference"):
            added += 1
    
    print("=== Expiry Reference Loaded ===")
    print(f"Records added: {added}")
    print(f"Total reference records: {len(katsu_db.load_data('expiry_ref.json').get('expiry_reference', []))}")
    
    # Show summary by category
    all_refs = katsu_db.load_data("expiry_ref.json").get("expiry_reference", [])
    categories = {}
    for r in all_refs:
        cat = r.get("ingredient_category", "Unknown")
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(r.get("ingredient_name", ""))
    
    print("\nReference by Category:")
    for cat, items in categories.items():
        names = ", ".join(items[:5])
        if len(items) > 5:
            names = names + "..."
        print("  %s (%d items): %s" % (cat, len(items), names))
    
    return True


def parse_date(date_str):
    """Parse a date string, returning None if invalid."""
    if not date_str:
        return None
    try:
        return datetime.strptime(str(date_str)[:10], "%Y-%m-%d")
    except (ValueError, TypeError):
        return None


def get_batch_expiry_info(batch):
    """Get expiry date, type, and shelf life for a batch."""
    actual = batch.get("actual_expiry_date")
    estimated = batch.get("estimated_expiry_date")
    shelf_life = batch.get("shelf_life_days")
    
    if actual:
        return actual, "confirmed", shelf_life
    elif estimated:
        return estimated, "estimated", shelf_life
    return None, "unknown", shelf_life


def calculate_days_remaining(expiry_date_str):
    """Calculate days remaining until expiry."""
    expiry = parse_date(expiry_date_str)
    if not expiry:
        return None
    
    today = datetime.now()
    delta = (expiry.date() - today.date()).days
    return delta


def determine_warning_status(batch):
    """
    Determine expiry warning status based on rules:
    - Shelf life > 7 days: warn 7 days before expiry
    - Shelf life <= 7 days: warn 1 day before expiry
    - Already expired: immediate prominent warning
    """
    expiry_date, expiry_type, shelf_life = get_batch_expiry_info(batch)
    
    if not expiry_date:
        return "NO_EXPIRY_DATE", "Unknown - no expiry date recorded"
    
    days_remaining = calculate_days_remaining(expiry_date)
    
    if days_remaining is None:
        return "ERROR", "Unable to parse expiry date"
    
    if days_remaining < 0:
        return "EXPIRED", f"Expired {-days_remaining} days ago (expiry: {expiry_date})"
    
    if days_remaining == 0:
        return "EXPIRED", f"Expires TODAY ({expiry_date})"
    
    # Determine warning threshold
    if shelf_life and shelf_life > 7:
        threshold = 7
    elif shelf_life and shelf_life <= 7:
        threshold = 1
    else:
        # Unknown shelf life - use 7-day default for safety
        # But also check if the batch is close to expiry
        if days_remaining <= 1:
            threshold = 1
        else:
            threshold = 7
    
    if days_remaining <= threshold:
        return "WARNING", f"Expiring in {days_remaining} days ({expiry_date})"
    
    return "OK", f"{days_remaining} days remaining ({expiry_date})"


def check_all_expiry():
    """Check all batches and return their status."""
    batch_data = katsu_db.load_data("batches.json")
    batches = batch_data.get("batches", [])
    
    results = []
    for batch in batches:
        if not batch.get("active", True):
            continue
        
        expiry_date, expiry_type, shelf_life = get_batch_expiry_info(batch)
        status, message = determine_warning_status(batch)
        days_remaining = calculate_days_remaining(expiry_date) if expiry_date else None
        
        results.append({
            "batch_id": batch.get("id"),
            "ingredient": batch.get("ingredient_name"),
            "supplier": batch.get("supplier"),
            "po_reference": batch.get("po_reference"),
            "remaining_amount": batch.get("remaining_amount", 0),
            "unit": batch.get("unit", ""),
            "expiry_date": expiry_date,
            "expiry_type": expiry_type,
            "shelf_life_days": shelf_life,
            "days_remaining": days_remaining,
            "status": status,
            "message": message,
            "storage_conditions": batch.get("storage_conditions", "")
        })
        
        # Update batch status in storage
        batch_data_local = katsu_db.load_data("batches.json")
        for b in batch_data_local.get("batches", []):
            if b["id"] == batch["id"]:
                b["expiry_status"] = status
                break
        katsu_db.save_data("batches.json", batch_data_local)
    
    return results


def show_expiry():
    """Display all batch expiry information as a table."""
    results = check_all_expiry()
    
    print("=== Expiry Status Report ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    if not results:
        print("No active batches found. Upload a Purchase Order to create batches.")
        return
    
    # Separate by status
    expired = [r for r in results if r["status"] == "EXPIRED"]
    warnings = [r for r in results if r["status"] == "WARNING"]
    ok = [r for r in results if r["status"] == "OK"]
    no_expiry = [r for r in results if r["status"] == "NO_EXPIRY_DATE"]
    
    # Show expired first (most urgent)
    if expired:
        print("🚨 EXPIRED STOCK - IMMEDIATE ATTENTION REQUIRED")
        print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Expiry Date':<12} | {'Days':<6} | {'Type'}")
        print("-" * 85)
        for r in expired:
            days = r["days_remaining"] if r["days_remaining"] is not None else "N/A"
            print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
                  f"{r['expiry_date']:<12} | {str(days):<6} | {r['expiry_type']}")
        print()
    
    if warnings:
        print("⚠️  EXPIRY WARNINGS - Action needed soon")
        print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Expiry Date':<12} | {'Days':<6} | {'Type'}")
        print("-" * 85)
        for r in warnings:
            days = r["days_remaining"] if r["days_remaining"] is not None else "N/A"
            print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
                  f"{r['expiry_date']:<12} | {str(days):<6} | {r['expiry_type']}")
        print()
    
    if no_expiry:
        print("❓ NO EXPIRY DATE - Needs attention")
        print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Shelf Life':<10} | {'Storage'}")
        print("-" * 85)
        for r in no_expiry:
            shelf = f"{r['shelf_life_days']}d" if r["shelf_life_days"] else "Unknown"
            print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
                  f"{shelf:<10} | {r['storage_conditions']}")
        print()
    
    if ok:
        print("✓ OK - Within safe period")
        print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Expiry Date':<12} | {'Days':<6} | {'Type'}")
        print("-" * 85)
        for r in ok:
            days = r["days_remaining"] if r["days_remaining"] is not None else "N/A"
            print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
                  f"{r['expiry_date']:<12} | {str(days):<6} | {r['expiry_type']}")
        print()
    
    # Summary
    print(f"=== Summary ===")
    print(f"  Total active batches: {len(results)}")
    print(f"  Expired: {len(expired)}")
    print(f"  Warning: {len(warnings)}")
    print(f"  OK: {len(ok)}")
    print(f"  No expiry date: {len(no_expiry)}")
    
    if expired:
        print(f"\n⚠️  {len(expired)} batch(es) have EXPIRED. Remove from usable inventory immediately.")
    if warnings:
        print(f"⚠️  {len(warnings)} batch(es) are in WARNING period. Use or dispose soon.")
    if no_expiry:
        print(f"❓ {len(no_expiry)} batch(es) have no expiry date. Update with actual or estimated dates.")


def show_expired_only():
    """Show only expired batches."""
    results = check_all_expiry()
    expired = [r for r in results if r["status"] == "EXPIRED"]
    
    print("=== Expired Stock Report ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    if not expired:
        print("No expired stock found.")
        return
    
    print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Expiry Date':<12} | {'Type':<10} | {'Storage'}")
    print("-" * 95)
    for r in expired:
        print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
              f"{r['expiry_date']:<12} | {r['expiry_type']:<10} | {r['storage_conditions']}")
    
    print(f"\nTotal expired batches: {len(expired)}")
    print("These batches should be removed from usable inventory and marked for review.")


def show_warnings_only():
    """Show only batches in warning period."""
    results = check_all_expiry()
    warnings = [r for r in results if r["status"] == "WARNING"]
    
    print("=== Expiry Warning Report ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    if not warnings:
        print("No batches in warning period.")
        return
    
    print(f"{'Ingredient':<20} | {'Batch':<12} | {'Remaining':<15} | {'Expiry Date':<12} | {'Days':<6} | {'Type'}")
    print("-" * 85)
    for r in warnings:
        print(f"{r['ingredient']:<20} | {r['batch_id']:<12} | {r['remaining_amount']:.1f} {r['unit']:<8} | "
              f"{r['expiry_date']:<12} | {str(r['days_remaining']):<6} | {r['expiry_type']}")
    
    print(f"\nTotal batches in warning period: {len(warnings)}")


def show_batch_details(batch_id):
    """Show details for a specific batch."""
    batch_data = katsu_db.load_data("batches.json")
    batch = None
    for b in batch_data.get("batches", []):
        if b["id"] == batch_id:
            batch = b
            break
    
    if not batch:
        print(f"Batch '{batch_id}' not found.")
        return
    
    print(f"=== Batch Details: {batch_id} ===")
    print(f"  Ingredient: {batch.get('ingredient_name', '')}")
    print(f"  Supplier: {batch.get('supplier', '')}")
    print(f"  PO Reference: {batch.get('po_reference', '')}")
    print(f"  Purchase Date: {batch.get('purchase_date', '')}")
    print(f"  Receipt Date: {batch.get('receipt_date', '')}")
    print(f"  Registration Date: {batch.get('registration_date', '')}")
    print(f"  Quantity Received: {batch.get('quantity_received_qty', 0)} Qty ({batch.get('quantity_received_amount', 0)} {batch.get('unit', '')})")
    print(f"  Pack Size: {batch.get('pack_size', '')}")
    print(f"  Actual Expiry: {batch.get('actual_expiry_date', 'Not provided')}")
    print(f"  Estimated Expiry: {batch.get('estimated_expiry_date', 'Not calculated')}")
    print(f"  Shelf Life: {batch.get('shelf_life_days', 'Unknown')} days")
    print(f"  Storage: {batch.get('storage_conditions', '')}")
    print(f"  Remaining: {batch.get('remaining_amount', 0)} {batch.get('unit', '')}")
    print(f"  Status: {batch.get('expiry_status', 'Unknown')}")
    print(f"  Expiry Type: {batch.get('expiry_type', 'Unknown')}")
    print(f"  Active: {'Yes' if batch.get('active', True) else 'No'}")
    
    # Check current status
    status, message = determine_warning_status(batch)
    print(f"\n  Current Status: {status}")
    print(f"  Message: {message}")


def set_expiry_date(batch_id, expiry_date):
    """Set the actual expiry date for a batch."""
    batch_data = katsu_db.load_data("batches.json")
    found = False
    
    for b in batch_data.get("batches", []):
        if b["id"] == batch_id:
            b["actual_expiry_date"] = expiry_date
            b["expiry_type"] = "confirmed"
            
            # Recalculate shelf life if we have receipt date
            receipt = parse_date(b.get("receipt_date"))
            expiry = parse_date(expiry_date)
            if receipt and expiry:
                delta = (expiry.date() - receipt.date()).days
                b["shelf_life_days"] = delta
            
            found = True
            break
    
    if not found:
        print(f"Batch '{batch_id}' not found.")
        return False
    
    if katsu_db.save_data("batches.json", batch_data):
        print(f"✓ Updated batch {batch_id}")
        print(f"  Actual Expiry Date: {expiry_date}")
        print(f"  Expiry Type: Confirmed")
    else:
        print(f"FAILED to update batch {batch_id}")
    
    return True


def write_off_batch(batch_id, reason):
    """Write off a batch (mark as expired/spoiled/discarded)."""
    batch_data = katsu_db.load_data("batches.json")
    batch = None
    
    for b in batch_data.get("batches", []):
        if b["id"] == batch_id:
            batch = b
            break
    
    if not batch:
        print(f"Batch '{batch_id}' not found.")
        return False
    
    remaining = batch.get("remaining_amount", 0)
    unit = batch.get("unit", "")
    ingredient = batch.get("ingredient_name", "")
    
    # Calculate waste cost
    ing = katsu_db.find_ingredient(ingredient)
    waste_cost = 0
    if ing and remaining > 0:
        waste_cost = remaining * ing.get("weighted_avg_cost_per_unit", 0)
    
    # Mark batch as inactive
    for b in batch_data.get("batches", []):
        if b["id"] == batch_id:
            b["active"] = False
            b["expiry_status"] = "WRITTEN_OFF"
            b["write_off_reason"] = reason
            b["write_off_date"] = datetime.now().strftime("%Y-%m-%d")
            break
    katsu_db.save_data("batches.json", batch_data)
    
    # Update ingredient stock (remove written-off amount)
    if ing:
        ing_data = katsu_db.load_data("ingredients.json")
        for i in ing_data.get("ingredients", []):
            if i["id"] == ing["id"]:
                i["current_stock_amount"] = max(0, i.get("current_stock_amount", 0) - remaining)
                i["last_updated"] = datetime.now().isoformat()
                break
        katsu_db.save_data("ingredients.json", ing_data)
    
    # Record write-off transaction
    katsu_db.record_transaction(
        ingredient_name=ingredient,
        quantity=remaining,
        unit=unit,
        txn_type="write_off",
        source="manual_write_off",
        reason=f"Batch {batch_id} written off: {reason}",
        batch_id=batch_id,
        value=waste_cost
    )
    
    # Record in write-offs file
    write_off = {
        "id": katsu_db.get_next_id("wo"),
        "batch_id": batch_id,
        "ingredient_name": ingredient,
        "quantity": remaining,
        "unit": unit,
        "waste_cost": waste_cost,
        "reason": reason,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "created": datetime.now().isoformat()
    }
    katsu_db.add_record("write_offs.json", write_off, "write_offs")
    
    print(f"=== Batch Written Off ===")
    print(f"  Batch: {batch_id}")
    print(f"  Ingredient: {ingredient}")
    print(f"  Quantity: {remaining} {unit}")
    print(f"  Waste Cost: RM{waste_cost:.2f}")
    print(f"  Reason: {reason}")
    print(f"  Batch marked as inactive and removed from usable inventory.")
    print(f"  Write-off recorded for financial reporting.")


def fefo_check(ingredient, amount, unit):
    """
    Check FEFO allocation without actually deducting.
    Shows which batches would be used and if there's enough stock.
    """
    batches = katsu_db.get_all_batches(ingredient_name=ingredient, active_only=True)
    
    print(f"=== FEFO Allocation Check ===")
    print(f"  Ingredient: {ingredient}")
    print(f"  Amount needed: {amount} {unit}")
    print()
    
    if not batches:
        print("  ⚠️  NO AVAILABLE BATCHES - Shortage!")
        print(f"  Shortage: {amount} {unit}")
        return
    
    remaining_needed = float(amount)
    total_available = sum(b.get("remaining_amount", 0) for b in batches)
    
    print(f"  Total available: {total_available:.1f} {unit} across {len(batches)} batches")
    print()
    
    print(f"  {'Batch':<12} | {'Expiry Date':<12} | {'Type':<10} | {'Available':<12} | {'Would Use':<12} | {'After':<12}")
    print("  " + "-" * 80)
    
    for batch in batches:
        if remaining_needed <= 0:
            batch_remaining = batch.get("remaining_amount", 0)
            expiry, exp_type, _ = get_batch_expiry_info(batch)
            print(f"  {batch['id']:<12} | {str(expiry):<12} | {exp_type:<10} | {batch_remaining:<12.1f} | {'0':<12} | {batch_remaining:<12.1f}")
            continue
        
        batch_available = batch.get("remaining_amount", 0)
        expiry, exp_type, shelf_life = get_batch_expiry_info(batch)
        
        # Check if expired
        is_expired = False
        if expiry:
            days = calculate_days_remaining(expiry)
            if days is not None and days < 0:
                is_expired = True
        
        if is_expired:
            print(f"  {batch['id']:<12} | {str(expiry):<12} | {exp_type:<10} | {batch_available:<12.1f} | {'SKIP':<12} | {batch_available:<12.1f} (EXPIRED)")
            continue
        
        use_from_batch = min(remaining_needed, batch_available)
        after = batch_available - use_from_batch
        
        print(f"  {batch['id']:<12} | {str(expiry):<12} | {exp_type:<10} | {batch_available:<12.1f} | {use_from_batch:<12.1f} | {after:<12.1f}")
        remaining_needed -= use_from_batch
    
    print()
    if remaining_needed > 0:
        print(f"  ⚠️  SHORTAGE: {remaining_needed:.1f} {unit} not available")
    else:
        print(f"  ✓ Sufficient stock available via FEFO allocation")


def main():
    if len(sys.argv) < 2:
        print("Usage: python expiry_manager.py <command> [args]")
        print("Commands:")
        print("  load-reference '<json>'            Load expiry reference data")
        print("  check                                Check all expiry status")
        print("  show                                 Show full expiry table")
        print("  show-expired                         Show only expired batches")
        print("  show-warnings                         Show batches in warning period")
        print("  show-batch <batch_id>                Show specific batch details")
        print("  set-expiry <batch_id> <date>         Set actual expiry date")
        print("  write-off <batch_id> '<reason>'      Write off a batch")
        print("  fefo-check <ingredient> <amt> <unit> Check FEFO allocation")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "load-reference":
        if len(sys.argv) < 3:
            print("Usage: python expiry_manager.py load-reference '<json_array>'")
            sys.exit(1)
        load_reference(sys.argv[2])
    
    elif command == "check":
        results = check_all_expiry()
        expired = [r for r in results if r["status"] == "EXPIRED"]
        warnings = [r for r in results if r["status"] == "WARNING"]
        
        if expired:
            print(f"🚨 {len(expired)} EXPIRED batch(es) found!")
            for r in expired:
                print(f"  {r['ingredient']} ({r['batch_id']}): {r['message']}")
        
        if warnings:
            print(f"⚠️  {len(warnings)} batch(es) in WARNING period:")
            for r in warnings:
                print(f"  {r['ingredient']} ({r['batch_id']}): {r['message']}")
        
        if not expired and not warnings:
            print(f"✓ All {len(results)} batch(es) are OK. No expiry warnings.")
    
    elif command == "show":
        show_expiry()
    
    elif command == "show-expired":
        show_expired_only()
    
    elif command == "show-warnings":
        show_warnings_only()
    
    elif command == "show-batch":
        if len(sys.argv) < 3:
            print("Usage: python expiry_manager.py show-batch <batch_id>")
            sys.exit(1)
        show_batch_details(sys.argv[2])
    
    elif command == "set-expiry":
        if len(sys.argv) < 4:
            print("Usage: python expiry_manager.py set-expiry <batch_id> <date>")
            sys.exit(1)
        set_expiry_date(sys.argv[2], sys.argv[3])
    
    elif command == "write-off":
        if len(sys.argv) < 4:
            print("Usage: python expiry_manager.py write-off <batch_id> '<reason>'")
            sys.exit(1)
        write_off_batch(sys.argv[2], sys.argv[3])
    
    elif command == "fefo-check":
        if len(sys.argv) < 5:
            print("Usage: python expiry_manager.py fefo-check <ingredient> <amount> <unit>")
            sys.exit(1)
        fefo_check(sys.argv[2], float(sys.argv[3]), sys.argv[4])
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
