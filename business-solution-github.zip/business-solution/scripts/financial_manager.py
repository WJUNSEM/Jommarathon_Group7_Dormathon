#!/usr/bin/env python3
"""
Katsu Zushi - Financial Manager
Handles sales revenue, COGS, gross/operating/net profit, expense management,
menu item profitability, and weekly/monthly/annual/custom financial reports.

Usage:
    python financial_manager.py add-expense '<json>'               # Add expense record
    python financial_manager.py list-expenses [category] [start] [end]  # List expenses
    python financial_manager.py report <type> [start] [end]        # Generate financial report
    python financial_manager.py menu-profit                         # Menu item profitability
    python financial_manager.py compare <period1> <period2>       # Compare periods
    python financial_manager.py add-category <name>                # Add expense category
    python financial_manager.py list-categories                     # List expense categories
"""

import json
import sys
import os
from datetime import datetime, date, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import katsu_db


# ============================================================================
# EXPENSE MANAGEMENT
# ============================================================================

def add_expense(expense_json):
    """Add a business expense record."""
    data = json.loads(expense_json) if isinstance(expense_json, str) else expense_json
    
    # Check for duplicates (same date, category, amount, description)
    expenses = katsu_db.get_all_expenses()
    for e in expenses:
        if (e.get("date") == data.get("date") and 
            e.get("category") == data.get("category") and
            e.get("amount") == float(data.get("amount", 0)) and
            e.get("description") == data.get("description", "")):
            print(f"⚠️  DUPLICATE DETECTED: Expense already exists")
            print(f"  Date: {e.get('date')}, Category: {e.get('category')}, Amount: RM{e.get('amount')}")
            print("  Record not added. Use a different description or remove the existing record first.")
            return False
    
    expense = {
        "id": katsu_db.get_next_id("exp"),
        "date": data.get("date", datetime.now().strftime("%Y-%m-%d")),
        "category": data.get("category", "Other Operating Expenses"),
        "description": data.get("description", ""),
        "payee": data.get("payee", ""),
        "amount": float(data.get("amount", 0)),
        "currency": "RM",
        "payment_status": data.get("payment_status", "pending"),
        "supporting_document": data.get("supporting_document"),
        "source_file": data.get("source_file"),
        "file_hash": data.get("file_hash"),
        "created": datetime.now().isoformat()
    }
    
    if katsu_db.add_record("expenses.json", expense, "expenses"):
        print(f"✓ Expense added: [{expense['id']}]")
        print(f"  Date: {expense['date']}")
        print(f"  Category: {expense['category']}")
        print(f"  Description: {expense['description']}")
        print(f"  Amount: RM{expense['amount']:.2f}")
        print(f"  Payment Status: {expense['payment_status']}")
    else:
        print("FAILED to add expense")
    
    return True


def list_expenses(category=None, start_date=None, end_date=None):
    """List expenses, optionally filtered."""
    expenses = katsu_db.get_all_expenses(start_date=start_date, end_date=end_date, category=category)
    
    print("=== Expense List ===")
    if category:
        print(f"Category: {category}")
    if start_date or end_date:
        print(f"Period: {start_date or '...'} to {end_date or '...'}")
    print(f"Total records: {len(expenses)}")
    print()
    
    if not expenses:
        print("No expenses found.")
        return
    
    print(f"{'Date':<12} | {'Category':<25} | {'Description':<30} | {'Payee':<20} | {'Amount':<10} | {'Status'}")
    print("-" * 115)
    
    total = 0
    for e in expenses:
        print(f"{e.get('date', ''):<12} | {e.get('category', ''):<25} | {e.get('description', ''):<30} | "
              f"{e.get('payee', ''):<20} | RM{e.get('amount', 0):<8.2f} | {e.get('payment_status', '')}")
        total += e.get("amount", 0)
    
    print("-" * 115)
    print(f"{'':12} | {'':25} | {'':30} | {'TOTAL':<20} | RM{total:<8.2f} |")


def add_category(name):
    """Add a new expense category."""
    config = katsu_db.get_config()
    categories = config.get("expense_categories", [])
    
    name = name.strip()
    if name in categories:
        print(f"Category '{name}' already exists.")
        return
    
    categories.append(name)
    config["expense_categories"] = categories
    if katsu_db.save_data("config.json", config):
        print(f"✓ Category added: {name}")
    else:
        print("FAILED to add category")


def list_categories():
    """List all expense categories."""
    config = katsu_db.get_config()
    categories = config.get("expense_categories", [])
    
    print("=== Expense Categories ===")
    for i, cat in enumerate(categories, 1):
        print(f"  {i}. {cat}")


# ============================================================================
# FINANCIAL CALCULATIONS
# ============================================================================

def get_period_dates(period_type, start_str=None, end_str=None):
    """Get date range for a reporting period."""
    today = date.today()
    
    if period_type == "weekly":
        start = today - timedelta(days=today.weekday())  # Monday
        end = start + timedelta(days=6)  # Sunday
        label = f"Week of {start.strftime('%Y-%m-%d')} to {end.strftime('%Y-%m-%d')}"
    elif period_type == "monthly":
        start = date(today.year, today.month, 1)
        if today.month == 12:
            end = date(today.year, 12, 31)
        else:
            end = date(today.year, today.month + 1, 1) - timedelta(days=1)
        label = f"{today.strftime('%B %Y')}"
    elif period_type == "annual":
        start = date(today.year, 1, 1)
        end = date(today.year, 12, 31)
        label = f"Year {today.year}"
    elif period_type == "custom" and start_str and end_str:
        start = datetime.strptime(start_str, "%Y-%m-%d").date()
        end = datetime.strptime(end_str, "%Y-%m-%d").date()
        label = f"{start.strftime('%Y-%m-%d')} to {end.strftime('%Y-%m-%d')}"
    else:
        start = date(today.year, today.month, 1)
        end = today
        label = f"Current month to date"
    
    is_complete = end < today
    return start, end, label, is_complete


def calculate_sales_revenue(start_date, end_date):
    """Calculate sales revenue for a period."""
    sales = katsu_db.get_all_sales(start_date=start_date, end_date=end_date)
    
    gross_sales = 0
    total_discounts = 0
    total_refunds = 0
    net_revenue = 0
    
    for s in sales:
        gross = s.get("gross_sales", 0)
        if gross == 0:
            gross = s.get("quantity_sold", 0) * s.get("selling_price", 0)
        
        discounts = s.get("discounts", 0)
        refunds = s.get("refunds", 0)
        
        if "net_sales_revenue" in s and s["net_sales_revenue"]:
            net = s["net_sales_revenue"]
        else:
            net = gross - discounts - refunds
        
        gross_sales += gross
        total_discounts += discounts
        total_refunds += refunds
        net_revenue += net
    
    return {
        "gross_sales": gross_sales,
        "discounts": total_discounts,
        "refunds": total_refunds,
        "net_sales_revenue": net_revenue,
        "transaction_count": len(sales)
    }


def calculate_cogs(start_date, end_date):
    """
    Calculate Cost of Goods Sold using recipe-based method.
    COGS = Sum of (ingredient qty consumed x cost per standard unit) for all sales.
    """
    sales = katsu_db.get_all_sales(start_date=start_date, end_date=end_date)
    recipe_data = katsu_db.load_data("recipes.json")
    ing_data = katsu_db.load_data("ingredients.json")
    
    # Build ingredient lookup with costs
    ing_costs = {}
    for ing in ing_data.get("ingredients", []):
        ing_costs[ing["name"].lower()] = {
            "cost_per_unit": ing.get("weighted_avg_cost_per_unit", 0),
            "unit": ing.get("standard_unit", "g")
        }
    
    total_cogs = 0
    ingredient_costs = {}
    
    for s in sales:
        menu_item = s.get("menu_item", "")
        qty_sold = s.get("quantity_sold", 0)
        
        recipe = katsu_db.find_recipe(menu_item)
        if not recipe:
            continue
        
        for recipe_ing in recipe.get("ingredients", []):
            ing_name = recipe_ing["name"].lower()
            ing_qty = float(recipe_ing.get("quantity", 0))
            
            cost_info = ing_costs.get(ing_name)
            if cost_info:
                cost = ing_qty * cost_info["cost_per_unit"] * qty_sold
                total_cogs += cost
                
                display_name = recipe_ing["name"]
                if display_name in ingredient_costs:
                    ingredient_costs[display_name] += cost
                else:
                    ingredient_costs[display_name] = cost
    
    # Add write-off costs
    write_off_data = katsu_db.load_data("write_offs.json")
    write_off_cost = 0
    for wo in write_off_data.get("write_offs", []):
        wo_date = wo.get("date", "")
        if start_date <= wo_date <= end_date:
            write_off_cost += wo.get("waste_cost", 0)
    
    return {
        "cogs": total_cogs,
        "ingredient_costs": ingredient_costs,
        "write_off_cost": write_off_cost,
        "total_cogs_with_writeoffs": total_cogs + write_off_cost,
        "method": "recipe_based"
    }


def calculate_operating_expenses(start_date, end_date):
    """Calculate total operating expenses for a period."""
    expenses = katsu_db.get_all_expenses(start_date=start_date, end_date=end_date)
    
    total = 0
    by_category = {}
    
    for e in expenses:
        amount = e.get("amount", 0)
        total += amount
        cat = e.get("category", "Other")
        if cat in by_category:
            by_category[cat] += amount
        else:
            by_category[cat] = amount
    
    return {
        "total": total,
        "by_category": by_category,
        "count": len(expenses)
    }


def generate_report(period_type, start_str=None, end_str=None):
    """Generate a complete financial report."""
    start, end, label, is_complete = get_period_dates(period_type, start_str, end_str)
    
    # Calculate all metrics
    sales = calculate_sales_revenue(start.isoformat(), end.isoformat())
    cogs = calculate_cogs(start.isoformat(), end.isoformat())
    opex = calculate_operating_expenses(start.isoformat(), end.isoformat())
    
    gross_profit = sales["net_sales_revenue"] - cogs["total_cogs_with_writeoffs"]
    operating_profit = gross_profit - opex["total"]
    
    # Check for missing data
    is_preliminary = False
    missing_notes = []
    
    if sales["transaction_count"] == 0:
        missing_notes.append("No sales records for this period")
        is_preliminary = True
    
    if cogs["cogs"] == 0 and sales["transaction_count"] > 0:
        missing_notes.append("COGS is zero - check if recipe costs are recorded")
        is_preliminary = True
    
    if opex["total"] == 0:
        missing_notes.append("No operating expenses recorded for this period")
    
    net_profit_label = "Preliminary Profit" if is_preliminary else "Net Profit"
    
    if sales["net_sales_revenue"] > 0:
        margin = (operating_profit / sales["net_sales_revenue"]) * 100
        margin_str = f"{margin:.1f}%"
    else:
        margin_str = "N/A"
    
    # ============= PART A: FINANCIAL SUMMARY =============
    print("=" * 60)
    print(f"  Katsu Zushi Financial Report")
    print(f"  Period: {label}")
    print(f"  Status: {'Complete' if is_complete else 'In Progress (partial period)'}")
    print("=" * 60)
    print()
    
    print("PART A: Financial Summary")
    print()
    print(f"{'Metric':<40} | {'Amount (RM)':<15}")
    print("-" * 60)
    print(f"{'Gross Sales':<40} | {sales['gross_sales']:<15.2f}")
    print(f"{'Discounts and Refunds':<40} | {sales['discounts'] + sales['refunds']:<15.2f}")
    print(f"{'Net Sales Revenue':<40} | {sales['net_sales_revenue']:<15.2f}")
    print(f"{'Cost of Goods Sold (COGS)':<40} | {cogs['total_cogs_with_writeoffs']:<15.2f}")
    print(f"{'  - Ingredient Costs':<40} | {cogs['cogs']:<15.2f}")
    print(f"{'  - Write-off Costs':<40} | {cogs['write_off_cost']:<15.2f}")
    print(f"{'Gross Profit':<40} | {gross_profit:<15.2f}")
    print(f"{'Operating Expenses':<40} | {opex['total']:<15.2f}")
    print(f"{'Operating Profit':<40} | {operating_profit:<15.2f}")
    print(f"{'Other Income and Expenses':<40} | {'0.00':<15}")
    print(f"{net_profit_label + ':':<40} | {operating_profit:<15.2f}")
    print(f"{'Net Profit Margin':<40} | {margin_str:<15}")
    print("-" * 60)
    print()
    
    if missing_notes:
        print("⚠️  DATA NOTES:")
        for note in missing_notes:
            print(f"   - {note}")
        print()
    
    # ============= PART B: EXPENSE BREAKDOWN =============
    print("PART B: Expense Breakdown")
    print()
    
    if opex["by_category"]:
        total_exp = opex["total"]
        print(f"{'Expense Category':<35} | {'Total (RM)':<12} | {'Percentage':<12}")
        print("-" * 65)
        
        sorted_cats = sorted(opex["by_category"].items(), key=lambda x: x[1], reverse=True)
        for cat, amount in sorted_cats:
            pct = (amount / total_exp * 100) if total_exp > 0 else 0
            print(f"{cat:<35} | {amount:<12.2f} | {pct:.1f}%")
        
        print("-" * 65)
        print(f"{'TOTAL':<35} | {total_exp:<12.2f} | 100.0%")
    else:
        print("No operating expenses recorded for this period.")
    print()
    
    # ============= PART C: SALES AND PROFIT TRENDS =============
    print("PART C: Sales and Profit Trends")
    print()
    
    # Compare with previous equivalent period
    period_days = (end - start).days + 1
    prev_start = start - timedelta(days=period_days)
    prev_end = start - timedelta(days=1)
    
    prev_sales = calculate_sales_revenue(prev_start.isoformat(), prev_end.isoformat())
    prev_cogs = calculate_cogs(prev_start.isoformat(), prev_end.isoformat())
    prev_opex = calculate_operating_expenses(prev_start.isoformat(), prev_end.isoformat())
    prev_gross_profit = prev_sales["net_sales_revenue"] - prev_cogs["total_cogs_with_writeoffs"]
    prev_operating_profit = prev_gross_profit - prev_opex["total"]
    
    print(f"  Comparison with previous period ({prev_start.strftime('%Y-%m-%d')} to {prev_end.strftime('%Y-%m-%d')}):")
    print()
    print(f"  {'Metric':<25} | {'Current (RM)':<15} | {'Previous (RM)':<15} | {'Change':<15} | {'Change %'}")
    print("  " + "-" * 85)
    
    metrics = [
        ("Gross Sales", sales["gross_sales"], prev_sales["gross_sales"]),
        ("Net Revenue", sales["net_sales_revenue"], prev_sales["net_sales_revenue"]),
        ("COGS", cogs["total_cogs_with_writeoffs"], prev_cogs["total_cogs_with_writeoffs"]),
        ("Gross Profit", gross_profit, prev_gross_profit),
        ("Operating Expenses", opex["total"], prev_opex["total"]),
        ("Operating Profit", operating_profit, prev_operating_profit),
    ]
    
    for name, curr, prev in metrics:
        change = curr - prev
        if prev > 0:
            change_pct = (change / prev) * 100
            pct_str = f"{change_pct:+.1f}%"
        else:
            pct_str = "N/A" if curr == 0 else "New"
        sign = "+" if change >= 0 else ""
        print(f"  {name:<25} | {curr:<15.2f} | {prev:<15.2f} | {sign}{change:<14.2f} | {pct_str}")
    
    print()
    
    # ============= PART D: MENU ITEM PROFITABILITY =============
    print("PART D: Menu Item Profitability (Estimated)")
    print()
    
    menu_profit_data = calculate_menu_profitability()
    
    if menu_profit_data:
        print(f"  {'Menu Item':<25} | {'Price':<8} | {'Ing Cost':<10} | {'Gross Profit':<13} | {'Margin':<10} | {'Rank'}")
        print("  " + "-" * 80)
        
        for i, item in enumerate(menu_profit_data, 1):
            margin_str = f"{item['margin']:.1f}%" if item['margin'] is not None else "N/A"
            print(f"  {item['menu_item']:<25} | RM{item['selling_price']:<6.2f} | RM{item['ingredient_cost']:<8.2f} | "
                  f"RM{item['gross_profit']:<11.2f} | {margin_str:<10} | #{i}")
        
        print()
        print("  Note: This is ESTIMATED gross profit per serving (ingredient costs only).")
        print("  It does not include packaging, delivery, or other business expenses.")
        print("  Use this for menu optimization, not as net profit.")
    else:
        print("  No menu items with sufficient data for profitability calculation.")
        print("  Ensure recipes and ingredient costs are recorded.")
    
    print()
    
    # ============= PART E: BUSINESS INSIGHTS =============
    print("PART E: Business Insights")
    print()
    
    insights = []
    
    # Largest expense category
    if opex["by_category"]:
        largest_cat = max(opex["by_category"].items(), key=lambda x: x[1])
        insights.append(f"Largest expense category: {largest_cat[0]} at RM{largest_cat[1]:.2f} "
                        f"({largest_cat[1]/opex['total']*100:.1f}% of total expenses)")
    
    # Sales trend
    if prev_sales["gross_sales"] > 0:
        sales_change = sales["gross_sales"] - prev_sales["gross_sales"]
        sales_pct = (sales_change / prev_sales["gross_sales"]) * 100
        direction = "increased" if sales_change > 0 else "decreased"
        insights.append(f"Sales {direction} by {abs(sales_pct):.1f}% compared to previous period")
    
    # Profit trend
    if prev_operating_profit != 0:
        profit_change = operating_profit - prev_operating_profit
        if prev_operating_profit > 0:
            profit_pct = (profit_change / prev_operating_profit) * 100
            direction = "improved" if profit_change > 0 else "declined"
            insights.append(f"Operating profit {direction} by {abs(profit_pct):.1f}% compared to previous period")
    
    # Menu profitability
    if menu_profit_data:
        best = menu_profit_data[0]
        worst = menu_profit_data[-1]
        insights.append(f"Highest estimated gross profit: {best['menu_item']} at RM{best['gross_profit']:.2f}/serving "
                        f"({best['margin']:.1f}% margin)")
        insights.append(f"Lowest estimated gross profit: {worst['menu_item']} at RM{worst['gross_profit']:.2f}/serving "
                        f"({worst['margin']:.1f}% margin)")
    
    # Write-off costs
    if cogs["write_off_cost"] > 0:
        insights.append(f"Inventory waste cost: RM{cogs['write_off_cost']:.2f} - review expiry management")
    
    # Missing data
    if missing_notes:
        insights.append(f"Report accuracy affected by: {'; '.join(missing_notes)}")
    
    # Cost-saving opportunity
    if cogs["cogs"] > 0 and sales["net_sales_revenue"] > 0:
        food_cost_pct = (cogs["cogs"] / sales["net_sales_revenue"]) * 100
        if food_cost_pct > 35:
            insights.append(f"Food cost is {food_cost_pct:.1f}% of revenue - above typical F&B target (25-35%). "
                            f"Consider supplier comparison or recipe optimization.")
    
    for i, insight in enumerate(insights, 1):
        print(f"  {i}. {insight}")
    
    print()
    print("  --- AI Recommendations (separate from factual calculations) ---")
    
    recs = []
    if opex["total"] > sales["net_sales_revenue"]:
        recs.append("Operating expenses exceed revenue. Review cost structure urgently.")
    if cogs["write_off_cost"] > 0:
        recs.append("Inventory waste detected. Improve FEFO compliance and ordering accuracy.")
    if menu_profit_data and worst and worst["margin"] is not None and worst["margin"] < 20:
        recs.append(f"Menu item '{worst['menu_item']}' has low margin ({worst['margin']:.1f}%). "
                    "Consider repricing or recipe adjustment.")
    if not recs:
        recs.append("Business metrics appear healthy. Continue monitoring trends.")
    
    for i, rec in enumerate(recs, 1):
        print(f"  R{i}. {rec}")
    
    print()
    print("=" * 60)
    print(f"  Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"  Method: Recipe-based COGS, Weighted-average ingredient costing")
    print(f"  This report is NOT audited or tax-compliant.")
    if is_preliminary:
        print(f"  ⚠️  This is a PRELIMINARY report - some data may be missing.")
    print("=" * 60)


def calculate_menu_profitability():
    """Calculate estimated gross profit for each menu item."""
    recipe_data = katsu_db.load_data("recipes.json")
    ing_data = katsu_db.load_data("ingredients.json")
    
    # Build ingredient cost lookup
    ing_costs = {}
    for ing in ing_data.get("ingredients", []):
        ing_costs[ing["name"].lower()] = {
            "cost_per_unit": ing.get("weighted_avg_cost_per_unit", 0),
            "unit": ing.get("standard_unit", "g")
        }
    
    results = []
    
    for recipe in recipe_data.get("recipes", []):
        menu_item = recipe.get("menu_item", "")
        selling_price = float(recipe.get("selling_price", 0))
        
        total_cost = 0
        all_costs_known = True
        
        for ing in recipe.get("ingredients", []):
            ing_name = ing["name"].lower()
            ing_qty = float(ing.get("quantity", 0))
            
            cost_info = ing_costs.get(ing_name)
            if cost_info and cost_info["cost_per_unit"] > 0:
                total_cost += ing_qty * cost_info["cost_per_unit"]
            else:
                all_costs_known = False
        
        gross_profit = selling_price - total_cost
        
        if selling_price > 0:
            margin = (gross_profit / selling_price) * 100
        else:
            margin = None
        
        results.append({
            "menu_item": menu_item,
            "selling_price": selling_price,
            "ingredient_cost": total_cost,
            "gross_profit": gross_profit,
            "margin": margin,
            "all_costs_known": all_costs_known
        })
    
    # Sort by gross profit (highest first)
    results.sort(key=lambda x: x["gross_profit"], reverse=True)
    
    return results


def menu_profit_report():
    """Display menu item profitability report."""
    data = calculate_menu_profitability()
    
    print("=== Menu Item Profitability (Estimated) ===")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()
    
    if not data:
        print("No menu items with recipes recorded.")
        print("Upload a Menu PDF to register recipes.")
        return
    
    print(f"{'Rank':<5} | {'Menu Item':<25} | {'Price':<8} | {'Ing Cost':<10} | {'Gross Profit':<13} | {'Margin':<10} | {'Cost Known'}")
    print("-" * 90)
    
    for i, item in enumerate(data, 1):
        margin_str = f"{item['margin']:.1f}%" if item['margin'] is not None else "N/A"
        cost_known = "Yes" if item['all_costs_known'] else "Partial"
        print(f"#{i:<4} | {item['menu_item']:<25} | RM{item['selling_price']:<6.2f} | RM{item['ingredient_cost']:<8.2f} | "
              f"RM{item['gross_profit']:<11.2f} | {margin_str:<10} | {cost_known}")
    
    print()
    print("Note: This is ESTIMATED gross profit (ingredient costs only).")
    print("Does not include packaging, delivery, rent, salaries, or other business expenses.")
    
    # Highlight items with unknown costs
    unknown = [d for d in data if not d["all_costs_known"]]
    if unknown:
        print(f"\n⚠️  {len(unknown)} item(s) have missing ingredient costs. Update supplier prices for accurate profitability.")


def compare_periods(period1, period2):
    """Compare two periods."""
    start1, end1, label1, _ = get_period_dates(period1)
    start2, end2, label2, _ = get_period_dates(period2)
    
    s1 = calculate_sales_revenue(start1.isoformat(), end1.isoformat())
    c1 = calculate_cogs(start1.isoformat(), end1.isoformat())
    e1 = calculate_operating_expenses(start1.isoformat(), end1.isoformat())
    gp1 = s1["net_sales_revenue"] - c1["total_cogs_with_writeoffs"]
    op1 = gp1 - e1["total"]
    
    s2 = calculate_sales_revenue(start2.isoformat(), end2.isoformat())
    c2 = calculate_cogs(start2.isoformat(), end2.isoformat())
    e2 = calculate_operating_expenses(start2.isoformat(), end2.isoformat())
    gp2 = s2["net_sales_revenue"] - c2["total_cogs_with_writeoffs"]
    op2 = gp2 - e2["total"]
    
    print("=== Period Comparison ===")
    print(f"Period 1: {label1} ({start1} to {end1})")
    print(f"Period 2: {label2} ({start2} to {end2})")
    print()
    
    print(f"{'Metric':<25} | {'Period 1 (RM)':<15} | {'Period 2 (RM)':<15} | {'Change (RM)':<15} | {'Change %'}")
    print("-" * 85)
    
    metrics = [
        ("Gross Sales", s1["gross_sales"], s2["gross_sales"]),
        ("Net Revenue", s1["net_sales_revenue"], s2["net_sales_revenue"]),
        ("COGS", c1["total_cogs_with_writeoffs"], c2["total_cogs_with_writeoffs"]),
        ("Gross Profit", gp1, gp2),
        ("Operating Expenses", e1["total"], e2["total"]),
        ("Operating Profit", op1, op2),
    ]
    
    for name, v1, v2 in metrics:
        change = v2 - v1
        if v1 > 0:
            pct = (change / v1) * 100
            pct_str = f"{pct:+.1f}%"
        else:
            pct_str = "N/A" if v2 == 0 else "New"
        sign = "+" if change >= 0 else ""
        print(f"{name:<25} | {v1:<15.2f} | {v2:<15.2f} | {sign}{change:<14.2f} | {pct_str}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python financial_manager.py <command> [args]")
        print("Commands:")
        print("  add-expense '<json>'                        Add expense record")
        print("  list-expenses [category] [start] [end]       List expenses")
        print("  report <type> [start] [end]                   Generate report (weekly/monthly/annual/custom)")
        print("  menu-profit                                   Menu item profitability")
        print("  compare <period1> <period2>                  Compare periods")
        print("  add-category <name>                           Add expense category")
        print("  list-categories                               List expense categories")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "add-expense":
        if len(sys.argv) < 3:
            print("Usage: python financial_manager.py add-expense '<json>'")
            sys.exit(1)
        add_expense(sys.argv[2])
    
    elif command == "list-expenses":
        category = sys.argv[2] if len(sys.argv) > 2 else None
        start = sys.argv[3] if len(sys.argv) > 3 else None
        end = sys.argv[4] if len(sys.argv) > 4 else None
        list_expenses(category, start, end)
    
    elif command == "report":
        if len(sys.argv) < 3:
            print("Usage: python financial_manager.py report <weekly|monthly|annual|custom> [start] [end]")
            sys.exit(1)
        period = sys.argv[2]
        start = sys.argv[3] if len(sys.argv) > 3 else None
        end = sys.argv[4] if len(sys.argv) > 4 else None
        generate_report(period, start, end)
    
    elif command == "menu-profit":
        menu_profit_report()
    
    elif command == "compare":
        if len(sys.argv) < 4:
            print("Usage: python financial_manager.py compare <period1> <period2>")
            sys.exit(1)
        compare_periods(sys.argv[2], sys.argv[3])
    
    elif command == "add-category":
        if len(sys.argv) < 3:
            print("Usage: python financial_manager.py add-category <name>")
            sys.exit(1)
        add_category(sys.argv[2])
    
    elif command == "list-categories":
        list_categories()
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
